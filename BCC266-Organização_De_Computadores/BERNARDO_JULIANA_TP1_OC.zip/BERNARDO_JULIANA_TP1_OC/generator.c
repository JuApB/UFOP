#include "generator.h"
#include <stdio.h>
#include <stdlib.h>

Instruction *generateRandomInstructions(int ramSize) {
  // 01|22|13|45 => isto é uma instrução
  // 02|33|12|01 => isto é outra instrução

  // 0 => salvar na memória
  // 1 => opcode => somar
  // 2 => opcode => subtrair
  //-1 => halt

  // 22 => significa um endereço da RAM (10 endereço)
  // 13 => significa 2o endereço
  // 45 => significa 3o endereco
  // ramSize => ESTA FORA DO INTERVALO DE 0 A ramSize DA MEMÓRIA RAM

  Instruction *instructions = (Instruction *)malloc(10 * sizeof(Instruction));

  for (int i = 0; i < 9; i++) {
    instructions[i].opcode = rand() % 4;      //-1, 0, 1, 2
    instructions[i].info1 = rand() % ramSize; // 0 ... RAM_SIZE
    do {
      instructions[i].info2 = rand() % ramSize; // 0 ... RAM_SIZE
    } while (instructions[i].info1 == instructions[i].info2);
    instructions[i].info3 = rand() % ramSize; // 0 ... RAM_SIZE
  }

  // inserindo a ultima instrucao do programa que nao faz nada que presta
  instructions[9].opcode = -1;
  instructions[9].info1 = -1;
  instructions[9].info2 = -1;
  instructions[9].info3 = -1;

  return instructions;
}

Instruction *generateMultiplicationInstructions(int info1, int info2,
                                                int *ramSize) {

  // Identifica o menor numero para uma lista de instrucoes menor
  int maior, menor;

  *ramSize = 2;

  if (info1 > info2) {
    maior = info1;
    menor = info2;
  } else {
    maior = info2;
    menor = info1;
  }

  if (menor == 0) {
    int aux = menor;
    menor = maior;
    maior = aux;
  }

  Instruction *instructions = (Instruction *)malloc(
      sizeof(Instruction) *
      (menor + 2)); // 2 instrucoes MOV + menor - 1 + instrucao de saida

  // Duas instrucoes de mover
  int i;
  for (i = 0; i < 2; i++) {
    instructions[i].opcode = 0;
    instructions[i].info1 = maior;
    instructions[i].info2 = i;
  }

  // Somas consecutivas
  for (; i <= menor; i++) {
    instructions[i].opcode = 1;
    instructions[i].info1 = 0;
    instructions[i].info2 = 1;
    instructions[i].info3 = 1;
  }

  // Encerra
  instructions[i].opcode = -1;
  instructions[i].info1 = -1;
  instructions[i].info2 = -1;
  instructions[i].info3 = -1;

  return instructions;
}

Instruction *generateDivisionInstructions(int info1, int info2, int *ramSize) {
  // Divide apenas numeros inteiros maiores que zero
  int dividendo = info1;
  int divisor = info2;

  *ramSize = 4;

  int quociente = dividendo / divisor;

  Instruction *instructions =
      (Instruction *)malloc(sizeof(Instruction) * ((quociente * 2) + 5));

  // Move
  instructions[0].opcode = 0;
  instructions[0].info1 = dividendo;
  instructions[0].info2 = 0;

  // Move
  instructions[1].opcode = 0;
  instructions[1].info1 = divisor;
  instructions[1].info2 = 1;

  // Move //resultado da divisao aqui
  instructions[2].opcode = 0;
  instructions[2].info1 = 0;
  instructions[2].info2 = 2;

  // para somar + 1
  instructions[3].opcode = 0;
  instructions[3].info1 = 1;
  instructions[3].info2 = 3;

  int i;
  for (i = 4; dividendo >= divisor; i += 2, dividendo -= divisor) {
    instructions[i].opcode = 2;
    instructions[i].info1 = 0;
    instructions[i].info2 = 1;
    instructions[i].info3 = 0;
    instructions[i + 1].opcode = 1;
    instructions[i + 1].info1 = 2;
    instructions[i + 1].info2 = 3;
    instructions[i + 1].info3 = 2;
  }

  // Encerra
  instructions[i].opcode = -1;
  instructions[i].info1 = -1;
  instructions[i].info2 = -1;
  instructions[i].info3 = -1;

  return instructions;
}

Instruction *generateExponentialInstructions(int base, int exponencial,
                                             int *ramSize) {
  *ramSize = 2;

  Instruction *instructions = (Instruction *)malloc(
      sizeof(Instruction) *
      (((exponencial - 1) * base) + 3 + (2 * (exponencial - 1))));
  // 3 *

  // Move
  instructions[0].opcode = 0;
  instructions[0].info1 = 0;
  instructions[0].info2 = 0;

  // Move
  instructions[1].opcode = 0;
  instructions[1].info1 = base;
  instructions[1].info2 = 1;

  int k = 2;
  for (int j = 0; j < exponencial - 1; j++) {
    // Multiplicacao
    for (int i = 0; i < base; i++, k++) {
      instructions[k].opcode = 1;
      instructions[k].info1 = 0;
      instructions[k].info2 = 1;
      instructions[k].info3 = 0;
    }
    // Move informacao
    instructions[k].opcode = 3;
    instructions[k].info1 = 0;
    instructions[k].info2 = 1;
    k++;
    // Move
    instructions[k].opcode = 0;
    instructions[k].info1 = 0;
    instructions[k].info2 = 0;
    k++;
  }

  // Encerra
  instructions[k].opcode = -1;
  instructions[k].info1 = -1;
  instructions[k].info2 = -1;
  instructions[k].info3 = -1;

  return instructions;
}

Instruction *generateFatorialInstructions(int numero, int *ramSize) {

  if (numero == 0 || numero == 1 || numero < 0) {
    *ramSize = 1;
    Instruction *instructions = (Instruction *)malloc(sizeof(Instruction) * 2);

    instructions[0].opcode = 0;
    instructions[0].info1 = 1;
    instructions[0].info2 = 0;

    instructions[1].opcode = -1;
    instructions[1].info1 = -1;
    instructions[1].info2 = -1;
    instructions[1].info3 = -1;

    return instructions;
  }

  *ramSize = 2;

  int instructionSize = ((numero - 1) * numero / 2) + (2 * numero) + 1;

  Instruction *instructions =
      (Instruction *)malloc(sizeof(Instruction) * instructionSize);
  int k = 0;
  instructions[k].opcode = 0;
  instructions[k].info1 = numero;
  instructions[k].info2 = 0;
  k++;

  // Zera o endereco 2 para o resulado
  instructions[k].opcode = 0;
  instructions[k].info1 = 0;
  instructions[k].info2 = 1;
  k++;

  // Subtrai 1 do endereço 1 e salva no 1
  // instructions[k].opcode = 2;
  // instructions[k].info1 = 1;
  // instructions[k].info2 = 2;
  // instructions[k].info3 = 1;
  // k++;
  // 5!
  // n = #0 //5
  // resultado = 0//#1
  numero--;
  int multiplicando = numero;
  for (int i = 0; i < numero; i++) {
    for (int j = 0; j < multiplicando; j++) {
      instructions[k].opcode = 1;
      instructions[k].info1 = 0;
      instructions[k].info2 = 1;
      instructions[k].info3 = 1;
      k++;
    }
    // Move o resultado da multiplicacao
    instructions[k].opcode = 3;
    instructions[k].info1 = 1;
    instructions[k].info2 = 0;
    k++;
    // Zera o endereco do resultado
    instructions[k].opcode = 0;
    instructions[k].info1 = 0;
    instructions[k].info2 = 1;
    k++;
    multiplicando--;
  }

  instructions[k].opcode = -1;
  instructions[k].info1 = -1;
  instructions[k].info2 = -1;
  instructions[k].info3 = -1;

  return instructions;
}

Instruction *readInstructions(char *fileName, int *ramSize) {
  printf("FILE -> %s\n", fileName);
  FILE *file = fopen(fileName, "r"); // Abrindo arquivo no modo leitura

  if (file == NULL) {
    printf("Arquivo nao pode ser aberto.\n");
    exit(1);
  }

  int n, i = 0;
  fscanf(file, "%d %d", ramSize, &n);
  Instruction *instructions = (Instruction *)malloc(n * sizeof(Instruction));
  while (i < n) {
    fscanf(file, "%d %d %d %d", &instructions[i].opcode, &instructions[i].info1,
           &instructions[i].info2, &instructions[i].info3);
    i++;
  }
  fclose(file); // Fechando o arquivo

  return instructions;
}
