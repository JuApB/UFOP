/*
  Nome: Juliana Aparecida Borges
  Matrícula: 21.2.4156
  Turma: 33
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcoes.h"

int main(){
    int opcoes, tabRecente[9][9], copiaTab[9][9], saida = 0;
    char dificuldade, nomeArq[100];

    //Impressão do MENU
    while (!saida) {
    printf("\n0 Sair do jogo \n1 Gerar novo jogo \n2 Carregar jogo \n3 Resolver jogo\n");
    printf("\nDigite sua opção: ");
    scanf("%d", &opcoes);

    //Implementando cada opcao do menu
    switch(opcoes){
      case 0:
        printf ("Tchau!!!\n");
        saida = 1;
        break;
      case 1:
        printf("Qual nível de dificuldade?\n");
        printf("F - Fácil\n");
        printf("D - Difícil\n");
        scanf("%s", &dificuldade);
        nivel(dificuldade, 1);
        lerComando(tabRecente, copiaTab, nomeArq);
        break;
      case 2:
        salvo();
        break;
      case 3:
        resolve(0, 0);
        break;  
      default:
        printf("Opção Inválida.\n");
        break;
      }
    }

    return 0;
}



