// cores e formato de texto
#define ANSI_RESET            "\x1b[0m"  
#define ANSI_BOLD             "\x1b[1m"  
#define ANSI_COLOR_RED        "\x1b[31m"
#define ANSI_BG_COLOR_RED     "\x1b[41m"

#define BOLD(string)       ANSI_BOLD             string ANSI_RESET
#define RED(string)        ANSI_COLOR_RED        string ANSI_RESET
#define BG_RED(string)     ANSI_BG_COLOR_RED     string ANSI_RESET

// Declaracao das variaveis: Matriz do sudoku nível fácil e nível difícil,
// Matriz do tabuleiro recem jogado e copia da matriz antes das jogadas.
int tabFacil[9][9] =
  {{ 0, 0, 6, 2, 0, 0, 0, 8, 4},
   { 0, 0, 8, 0, 7, 0, 0, 0, 0},
   { 0, 0, 4, 0, 1, 0, 5, 0, 7},
   { 8, 4, 0, 1, 6, 0, 0, 0, 2},
   { 2, 0, 0, 0, 0, 0, 0, 3, 5},
   { 6, 3, 0, 7, 5, 0, 0, 0, 0},
   { 0, 0, 2, 0, 4, 7, 1, 0, 0},
   { 0, 0, 3, 0, 2, 8, 4, 0, 9},
   { 0, 5, 0, 0, 0, 1, 2, 0, 0}};
int tabDificil[9][9] =  
  {{ 0, 0, 0, 7, 0, 0, 6, 0, 0},
   { 0, 8, 0, 0, 5, 0, 0, 0, 0},
   { 0, 0, 0, 0, 0, 0, 9, 0, 0},
   { 9, 0, 6, 0, 0, 0, 0, 0, 0},
   { 0, 0, 0, 0, 8, 0, 0, 5, 0},
   { 7, 0, 0, 0, 0, 0, 0, 0, 0},
   { 0, 0, 0, 9, 0, 2, 3, 0, 0},
   { 0, 0, 0, 1, 0, 0, 0, 0, 4},
   { 0, 2, 0, 0, 0, 0, 0, 8, 0}};  
int tabRecente[9][9] = {0}, copiaTab[9][9];

//funçao para preencher a matriz nivel facil
void preencheFacil() {
  int i,j;
  for(i = 0; i < 9; i++){
    for(j = 0; j < 9; j++){
      tabRecente[i][j] = tabFacil[i][j];
    }
  }
}

//funçao para preencher a matriz nivel dificil
void preencheDificil() {
  int i,j;
  for(i = 0; i < 9; i++){
    for(j = 0; j < 9; j++){
      tabRecente[i][j] = tabDificil[i][j];
    }
  }
}

//funcao para imprimir o tabuleiro com as cores
void desenhaTab(int tabRecente[9][9]) {
  printf("\n" BOLD(BG_RED("    1   2   3   4   5   6   7   8   9   ")));
  printf("\n" BOLD(BG_RED("  +-----------+-----------+-----------+ ")) "\n");
  for(int i = 0; i <= 8; i++){
    for(int j = 0; j <= 8; j++){
        if(j == 0) printf(BOLD(BG_RED("%d | ")), i+1);
        if(tabRecente[i][j] == 0){
            printf(BOLD(BG_RED(" _ ")));
        }
        else printf(BOLD(BG_RED(" %d ")), tabRecente[i][j]);
       if((j + 1) % 3 == 0) printf(BOLD(BG_RED(" | ")));
    }
    printf("\n");
    if((i + 1) % 3 == 0){
        printf(BOLD(BG_RED("  +-----------+-----------+-----------+ "))"\n");
        }    
    }
    printf("\n");    
}

//funcao para a escolha do nivel de dificuldade escolhido pelo usuario
void nivel(char dificuldade, int novoJogo) {
   if(novoJogo) {
     switch(dificuldade) {
       //Preenchendo a matriz no nivel Facil
       case 'F':
         preencheFacil(tabRecente);
         break;
      //Preenchendo a matriz no nivel Dificil
       case 'D':
         preencheDificil(tabRecente);
         break;
       default:
         break;
       }
     }
    desenhaTab(tabRecente); //imprimindo o tabuleiro
}

//função para preencher a matriz com os dados do arquivo já salvo
void preenche(int tabRecente[9][9], FILE *arq){
    for(int i = 0; i <= 8; i++){
        for(int j = 0; j <= 8; j++){
            fscanf(arq, "%d", &tabRecente[i][j]);
        }
    }
}

//funcao para preencher os dados novos do tabuleiro em uma outra matriz
void copia(int tabRecente[9][9], int copiaTab[9][9]){
    for(int i = 0; i < 9; i++){
        for(int j = 0; j < 9; j++){
            copiaTab[i][j] = tabRecente[i][j];
        }
    }
}

//funcao para salvar o jogo, solicitado pelo usuario
void salvaJogo(int tabRecente[9][9], char nomeArq[]){
    printf("Digite o nome do arquivo: "); //pedindo nome do arquivo
    scanf("%s", nomeArq);
    FILE *arq = fopen(nomeArq, "w");
    for(int i = 0; i < 9; i++){
        for(int j = 0; j < 9; j++){
            fprintf(arq, "%d ", tabRecente[i][j]); //escrevendo no arquivo
        }
        fprintf(arq, "\n");
    }
    fflush(stdin);// liberar buffer
    fclose(arq);
    printf("Jogo foi salvo em %s\n", nomeArq);
}

//funçao para identificar se o usuario está digitando numeros para jogar ou se é um comando de voltar/salvar
int entrada(int tabRecente[9][9], char comando[], int *col, int *lin, int *num, int *reg, char nomeArq[]){
     if((strcmp(comando, "voltar")) == 0){ //verificando se o comando do usuario é voltar
           *num = 42;
           return 0;
       }
     else if((strcmp(comando, "salvar")) == 0){ //verificando se o comando do usuario é salvar
           salvaJogo(tabRecente, nomeArq);
           return 0;
      }
     else{  //atribuindo os valores de entrada do jogo nas variaveis destinadas
           *reg = (comando[0]) - 10;
           *lin = (comando[1]) - 49;
           *col = (comando[2]) - 49;
           *num = (comando[3]) - 48;
      }
     return 1;
}

//funçao para checar se a celula de tal regiao ja possui valor
int checaCopia(int copiaTab[9][9], int lin, int col, int reg){
    if(copiaTab[lin][col] != 0){
        printf("Erro! A célula %d,%d da regiao %d ja possui valor.\n", (lin+1), (col+1), reg);
        return 1;
    }
    return 0;
}

//funçao para checar se a linha possui valor
int checaLinha(int tabRecente[9][9], int lin, int num){
    for(int i = 0; i < 9; i++){ //verificando linha
        if(tabRecente[lin][i] == num){
            printf("Erro! A linha %d ja possui o valor %d.\n", (lin+1), num);
            return 1;
        }
    }
    return 0; 
    
}

//funçao para checar se a coluna possui valor
int checaColuna(int tabRecente[9][9], int col, int num){
    for(int i = 0; i < 9; i++){ //verificando colunas
        if(tabRecente[i][col] == num){
            printf("Erro! A coluna %d ja possui o valor %d.\n", (col+1), num);
            return 1;
        }
    }
    return 0; 
}

//funçao para checar se a regiao vai possui o valor digitado
int checaRegiao(int tabRecente[9][9], int reg, int num){
     int inicReg, inicRegC;
    inicReg = (reg - 1) / 3 * 3;
    inicRegC = (reg - 1) % 3 * 3;
    for(int i = inicReg; i < (inicReg + 3); i++){
        for(int j = inicRegC; j < (inicRegC + 3); j++){
            if(tabRecente[i][j] == num){
                printf("Erro! A regiao %d já possui o valor %d.\n", reg, num);
                return 1;
            }
        }
    }
    return 0;
}

//funçao para verificar se todas posiçoes estao validas ou invalidas
int posicoesInvalidas(int tabRecente[9][9], int copiaTab[9][9], int col, int lin, int num, int reg){
    int checaCop = checaCopia(copiaTab, lin, col, reg);
    int checaL = checaLinha(tabRecente, lin, num);
    int checaC = checaColuna(tabRecente, col, num);
    int checaR = checaRegiao(tabRecente, reg, num);
    if(checaCop == 0 && checaL == 0 && checaC == 0 && checaR == 0){
        return 0;
    }
    else{
        return 1;
    }
}

//funçao para verificar se o usuario ganhou o jogo
void ganhou(int tabRecente[9][9], int *num){
    int venceu = 0;
    for(int i = 0; i < 9; i++){
        for(int j = 0; j < 9; j++){
            if((tabRecente[i][j]) != 0){
                venceu++;
            }
        }
    }
    if(venceu == 81){
        printf("Parabéns! Você completou o sudoku!\n\n");
        *num = 42;
    }
}

//funçao para ler os comandos digitados pelo usuario e verificar se estão validos ou não, assim imprimindo as informaçoes obtidas
void lerComando(int tabRecente[9][9], int copiaTab[9][9], char nomeArq[]){
    char comando[20];
    int col, lin, num, reg;
    do{
        printf("Digite um comando ou indique a celula a alterar: ");
        scanf("%s", comando);
        fflush(stdin);
        int seg = entrada(tabRecente, comando, &col, &lin, &num, &reg, nomeArq);
        if(seg > 0){
            int checaDados = posicoesInvalidas(tabRecente, copiaTab, col, lin, num, reg);
            if(seg != 0){
                if(checaDados == 0){
                    tabRecente[lin][col] = num;
                    desenhaTab(tabRecente);
                }
            } 
        }
        ganhou(tabRecente, &num);
    }while (num != 42);
}

//funçao para ler um arquivo salvo 
void salvo(){
    int tabRecente[9][9], copiaTab[9][9];
    char nomeArq[100];
    printf("Indique o arquivo texto contendo o jogo: ");
    scanf("%s", nomeArq);
    FILE *arq = fopen(nomeArq, "r");
    preenche(tabRecente, arq);
    fflush(stdin);
    fclose(arq); //fechando o arquivo
    copia(tabRecente, copiaTab);
    desenhaTab(tabRecente);
    lerComando(tabRecente, copiaTab, nomeArq);
}

//funcao para checar as linhas, colunas e regiões para poder resolver o tabuleiro
int checandoResolve(int lin, int col,int num){
    int i, j, linR, colR;
    // verifica coluna e linha
    if(copiaTab[lin][col] != 0) 
       return 0;
    for(i = 0; i < 9; i++){
       if(tabRecente[lin][i] == num || tabRecente[i][col] == num)
         return 0;

      }
    i = (lin / 3);
    j = (col / 3);

    //verifica região quadrada
    for(linR = i*3; linR < (i+1)*3; linR++){
       for(colR = j*3; colR < (j+1)*3; colR++){
          if(tabRecente[linR][colR] == num)
            return 0;

        }
    }
    return 1;
}
 
//funçao para resolver o tabuleiro 
void resolve(int lin, int col){
    int i;
    if(copiaTab[lin][col] != 0){
      if((col+1) < 9) 
        resolve(lin, col+1);

      else if((lin+1) < 9) 
        resolve(lin+1, 0);

    }
    else{
      for(i = 1; i <= 9; i++){
        if(checandoResolve(lin, col, i) == 1){
          tabRecente[lin][col] = i;
          if((col+1) < 9) 
            resolve(lin, col+1);

          else if((lin+1) < 9) 
            resolve(lin+1, 0);

        }
      }
    }
    if(lin == 8 && col == 8) 
      desenhaTab(tabRecente);

    if(copiaTab[lin][col] == 0) 
      tabRecente[lin][col] = 0;

}
