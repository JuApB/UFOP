#include <stdio.h>
#include <string.h>

// #include "lista.h"
#include "pilha.h"
#include "fila.h"

// void testaLista();
// void testaPilha();
void testaFila();

int main() {
    // testaLista();
    // testaPilha();
    testaFila();
    return 0;
}

// void testaLista() {
//     Lista* lista = ListaCria();
//     Item item;
//     printf("Lista Vazia: %s\n", ListaEhVazia(lista) ? "true" : "false");
//     item.chave = 1; strcpy(item.nome, "pedro");
//     printf("Inseriu 1: %s\n", ListaInsereFinal(lista, item) ? "true" : "false"); 
//     item.chave = 2; strcpy(item.nome, "henrique");
//     printf("Inseriu 2: %s\n", ListaInsereFinal(lista, item) ? "true" : "false"); 
//     item.chave = 3; strcpy(item.nome, "guilherme");
//     printf("Inseriu 3: %s\n", ListaInsereFinal(lista, item) ? "true" : "false"); 
//     item.chave = 4; strcpy(item.nome, "carlos");
//     printf("Inseriu 4: %s\n", ListaInsereFinal(lista, item) ? "true" : "false"); 
//     item.chave = 5; strcpy(item.nome, "jose");
//     printf("Inseriu 5: %s\n", ListaInsereFinal(lista, item) ? "true" : "false"); 
//     item.chave = 6; strcpy(item.nome, "joao");
//     printf("Inseriu 6: %s\n", ListaInsereFinal(lista, item) ? "true" : "false"); 
//     printf("Removeu: %s", ListaRetiraFinal(lista, &item) ? "true" : "false"); 
//     printf(" (%d - %s)\n", item.chave, item.nome);
//     item.chave = 7; strcpy(item.nome, "maria");
//     printf("Inseriu 7: %s\n", ListaInsereInicio(lista, item) ? "true" : "false"); 
//     printf("Lista Vazia: %s\n", ListaEhVazia(lista) ? "true" : "false");
//     ListaImprime(lista);
//     printf("Pegou: %s", ListaGet(lista, 1, &item) ? "true" : "false"); 
//     printf(" (%d - %s)\n", item.chave, item.nome);
//     ListaDestroi(&lista);
// }

// void testaPilha() {
//     Pilha* pilha = PilhaCria();
//     Item item;
//     printf("Pilha Vazia: %s\n", PilhaEhVazia(pilha) ? "true" : "false");
//     item.chave = 1; strcpy(item.nome, "pedro");
//     printf("Inseriu 1: %s\n", PilhaPush(pilha, item) ? "true" : "false"); 
//     item.chave = 2; strcpy(item.nome, "henrique");
//     printf("Inseriu 2: %s\n", PilhaPush(pilha, item) ? "true" : "false"); 
//     item.chave = 3; strcpy(item.nome, "guilherme");
//     printf("Inseriu 3: %s\n", PilhaPush(pilha, item) ? "true" : "false"); 
//     item.chave = 4; strcpy(item.nome, "carlos");
//     printf("Inseriu 4: %s\n", PilhaPush(pilha, item) ? "true" : "false"); 
//     item.chave = 5; strcpy(item.nome, "jose");
//     printf("Inseriu 5: %s\n", PilhaPush(pilha, item) ? "true" : "false"); 
//     item.chave = 6; strcpy(item.nome, "joao");
//     printf("Inseriu 6: %s\n", PilhaPush(pilha, item) ? "true" : "false"); 
//     printf("Removeu: %s", PilhaPop(pilha, &item) ? "true" : "false"); 
//     printf(" (%d - %s)\n", item.chave, item.nome);
//     item.chave = 7; strcpy(item.nome, "maria");
//     printf("Inseriu 7: %s\n", PilhaPush(pilha, item) ? "true" : "false"); 
//     printf("Removeu: %s", PilhaPop(pilha, &item) ? "true" : "false"); 
//     printf(" (%d - %s)\n", item.chave, item.nome);
//     printf("Pilha Vazia: %s\n", PilhaEhVazia(pilha) ? "true" : "false");
//     PilhaImprime(pilha);
//     item.chave = 7; strcpy(item.nome, "maria");
//     printf("Inseriu 7: %s\n", PilhaPush(pilha, item) ? "true" : "false"); 
//     PilhaImprime(pilha);
//     printf("Pegou: %s", PilhaTopo(pilha, &item) ? "true" : "false"); 
//     printf(" (%d - %s)\n", item.chave, item.nome);
//     pilha = PilhaDestroi(pilha);
// }

void testaFila() {
    Fila* fila = FilaCria();
    Item item;
    printf("Fila Vazia: %s\n", FilaEhVazia(fila) ? "true" : "false");
    item.chave = 1; strcpy(item.nome, "pedro");
    printf("Inseriu 1: %s\n", FilaEnfileira(fila, item) ? "true" : "false"); 
    item.chave = 2; strcpy(item.nome, "henrique");
    printf("Inseriu 2: %s\n", FilaEnfileira(fila, item) ? "true" : "false"); 
    item.chave = 3; strcpy(item.nome, "guilherme");
    printf("Inseriu 3: %s\n", FilaEnfileira(fila, item) ? "true" : "false"); 
    item.chave = 4; strcpy(item.nome, "carlos");
    printf("Inseriu 4: %s\n", FilaEnfileira(fila, item) ? "true" : "false"); 
    item.chave = 5; strcpy(item.nome, "jose");
    printf("Inseriu 5: %s\n", FilaEnfileira(fila, item) ? "true" : "false"); 
    item.chave = 6; strcpy(item.nome, "joao");
    printf("Inseriu 6: %s\n", FilaEnfileira(fila, item) ? "true" : "false"); 
    printf("Removeu: %s", FilaDesenfileira(fila, &item) ? "true" : "false"); 
    printf(" (%d - %s)\n", item.chave, item.nome);
    item.chave = 7; strcpy(item.nome, "maria");
    printf("Inseriu 7: %s\n", FilaEnfileira(fila, item) ? "true" : "false"); 
    printf("Removeu: %s", FilaDesenfileira(fila, &item) ? "true" : "false"); 
    printf(" (%d - %s)\n", item.chave, item.nome);
    printf("Fila Vazia: %s\n", FilaEhVazia(fila) ? "true" : "false");
    FilaImprime(fila);
    item.chave = 7; strcpy(item.nome, "maria");
    printf("Inseriu 7: %s\n", FilaEnfileira(fila, item) ? "true" : "false"); 
    FilaImprime(fila);
    fila = FilaDestroi(fila);
}