#include "pilha.h"
#include "lista.h"

#include <stdio.h>
#include <stdlib.h>

struct pilha {
    Lista* lista;
};

Pilha* PilhaCria() {
    Pilha* pilha = (Pilha*) malloc(sizeof(Pilha));
    pilha->lista = ListaCria();
    return pilha;
}

Pilha* PilhaDestroi(Pilha* pPilha) {
    ListaDestroi(&(pPilha->lista));
    free(pPilha);
    pPilha = NULL;
    return pPilha;
}

bool PilhaEhVazia(Pilha* pPilha) {
    return ListaEhVazia(pPilha->lista);
}

bool PilhaPush(Pilha* pPilha, Item item) {
    return ListaInsereFinal(pPilha->lista, item);
}

bool PilhaPop(Pilha* pPilha, Item* pItem) {
    return ListaRetiraFinal(pPilha->lista, pItem);
}

int PilhaTamanho(Pilha* pPilha) {
    return ListaTamanho(pPilha->lista);
}

void PilhaImprime(Pilha* pPilha) {
    ListaImprime(pPilha->lista);
}

bool PilhaTopo(Pilha* pPilha, Item* pItem) {
    return ListaGet(pPilha->lista, ListaTamanho(pPilha->lista) - 1, pItem);
}