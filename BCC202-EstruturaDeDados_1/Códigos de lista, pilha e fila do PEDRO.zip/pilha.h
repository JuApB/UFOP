#ifndef PILHA_H
#define PILHA_H

#include <stdbool.h>
#include "item.h"

typedef struct pilha Pilha;

Pilha* PilhaCria();
Pilha* PilhaDestroi(Pilha*);
bool PilhaEhVazia(Pilha*);
bool PilhaPush(Pilha*, Item);
bool PilhaPop(Pilha*, Item*);
int PilhaTamanho(Pilha*);
void PilhaImprime(Pilha*);
bool PilhaTopo(Pilha*, Item*);

#endif // PILHA_H