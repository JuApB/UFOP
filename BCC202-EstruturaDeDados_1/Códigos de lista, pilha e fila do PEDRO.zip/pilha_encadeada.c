#include "pilha.h"

#include <stdio.h>
#include <stdlib.h>

typedef struct celula {
    Item item;
    struct celula* prox;
} Celula;

struct pilha {
    Celula* topo;
    int tam;
};

Pilha* PilhaCria() {
    Pilha* pilha = (Pilha*) malloc(sizeof(Pilha));
    pilha->topo = NULL;
    pilha->tam = 0;
    return pilha;
}

Pilha* PilhaDestroi(Pilha* pPilha) {
    Item item;
    while(PilhaPop(pPilha, &item));
    free(pPilha);
    pPilha = NULL;
    return pPilha;
}

bool PilhaEhVazia(Pilha* pPilha) {
    // return pPilha->tam == 0;
    return pPilha->topo == NULL;
}

bool PilhaPush(Pilha* pPilha, Item item) {
    Celula* nova = (Celula*) malloc(sizeof(Celula));
    if (nova == NULL)
        return false;
    nova->item = item;
    nova->prox = pPilha->topo;
    pPilha->topo = nova;
    pPilha->tam++;
    return true;
}

bool PilhaPop(Pilha* pPilha, Item* pItem) {
    if (PilhaEhVazia(pPilha))
        return false;
    *pItem = pPilha->topo->item;
    Celula* aux = pPilha->topo;
    pPilha->topo = aux->prox;
    pPilha->tam--;
    free(aux);
    return true;
}

int PilhaTamanho(Pilha* pPilha) {
    return pPilha->tam;
}

void PilhaImprime(Pilha* pPilha) {
    printf("Pilha: [");
    Celula* aux = pPilha->topo;
    for (int i=0;i<pPilha->tam;i++) {
        printf("(%d|%s) ", aux->item.chave, aux->item.nome);
        aux = aux->prox;
    }
    printf("]\n");
}

bool PilhaTopo(Pilha* pPilha, Item* pItem) {
    if (PilhaEhVazia(pPilha))
        return false;
    *pItem = pPilha->topo->item;
    return true;
}