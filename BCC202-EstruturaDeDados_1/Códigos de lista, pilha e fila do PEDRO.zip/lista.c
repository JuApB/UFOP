#include "lista.h"
#include <stdlib.h>
#include <stdio.h>

#define MAX_TAM 5

struct lista {
    Item itens[MAX_TAM];
    int ultimo;
};

Lista* ListaCria() {
    Lista* lista = (Lista*) malloc(sizeof(Lista));
    if (lista == NULL)
        exit(1);
    lista->ultimo = 0;
    return lista;
}

void ListaDestroi(Lista** pLista) {
    free(*pLista);
    *pLista = NULL;
}

bool ListaEhVazia(Lista* pLista) {
    return pLista->ultimo == 0;
}

bool ListaInsereFinal(Lista* pLista, Item x) {
    if (pLista->ultimo == MAX_TAM)
        return false;
    pLista->itens[pLista->ultimo++] = x;
    return true;
}

bool ListaInsereInicio(Lista* pLista, Item x) {
    if (pLista->ultimo == MAX_TAM)
        return false;
    for (int i=pLista->ultimo;i>0;i--)
        pLista->itens[i] = pLista->itens[i - 1];
    pLista->itens[0] = x;
    pLista->ultimo++;
    return true;
}

bool ListaRetiraFinal(Lista* pLista, Item *pX) {
    if (ListaEhVazia(pLista))
        return false;
    (*pX) = pLista->itens[--pLista->ultimo];
    return true;
}

void ListaImprime(Lista* pLista) {
    printf("LISTA: [");
    for (int i=0;i<pLista->ultimo;i++)
        printf("(%d|%s) ", pLista->itens[i].chave, pLista->itens[i].nome);
    printf("]\n");
}

bool ListaGet(Lista* pLista, int p, Item *pX) {
    if (p >= ListaTamanho(pLista) || p < 0 )
        return false;
    (*pX) = pLista->itens[p];
    return true;
}

int ListaTamanho(Lista* pLista) {
    return pLista->ultimo;
}
