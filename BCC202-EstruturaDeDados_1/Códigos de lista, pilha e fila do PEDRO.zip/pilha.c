#include "pilha.h"

#include <stdio.h>
#include <stdlib.h>

#define MAX_TAM 5

struct pilha {
    Item itens[MAX_TAM];
    int tam;
};

Pilha* PilhaCria() {
    Pilha* pilha = (Pilha*) malloc(sizeof(Pilha));
    pilha->tam = 0;
    return pilha;
}

Pilha* PilhaDestroi(Pilha* pPilha) {
    free(pPilha);
    pPilha = NULL;
    return pPilha;
}

bool PilhaEhVazia(Pilha* pPilha) {
    return pPilha->tam == 0;
}

bool PilhaPush(Pilha* pPilha, Item item) {
    if (pPilha->tam == MAX_TAM)
        return false;
    pPilha->itens[pPilha->tam++] = item;
    return true;
}

bool PilhaPop(Pilha* pPilha, Item* pItem) {
    if (PilhaEhVazia(pPilha))
        return false;
    *pItem = pPilha->itens[--pPilha->tam];
    return true;
}

int PilhaTamanho(Pilha* pPilha) {
    return pPilha->tam;
}

void PilhaImprime(Pilha* pPilha) {
    printf("Pilha: [");
    for (int i=0;i<pPilha->tam;i++)
        printf("(%d|%s) ", pPilha->itens[i].chave, pPilha->itens[i].nome);
    printf("]\n");
}

bool PilhaTopo(Pilha* pPilha, Item* pItem) {
    if (PilhaEhVazia(pPilha))
        return false;
    *pItem = pPilha->itens[pPilha->tam - 1];
    return true;
}