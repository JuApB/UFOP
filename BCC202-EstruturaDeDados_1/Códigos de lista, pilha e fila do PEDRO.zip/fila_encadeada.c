#include "fila.h"
#include "item.h"

#include <stdlib.h>
#include <stdio.h>

typedef struct celula {
    Item item;
    struct celula* prox;
} Celula;

struct fila {
    Celula* primeiro;
    Celula* ultimo;
    int tam;
};

Fila* FilaCria() {
    Fila* fila = (Fila*) malloc(sizeof(Fila));
    fila->primeiro = (Celula*) malloc(sizeof(Celula));
    fila->primeiro->prox = NULL;
    fila->ultimo = fila->primeiro;
    fila->tam = 0;
    return fila;
}

Fila* FilaDestroi(Fila* pFila) {
    Item lixo;
    while (FilaDesenfileira(pFila, &lixo));
    free(pFila->primeiro);
    free(pFila);
    pFila = NULL;
    return pFila;
}

bool FilaEhVazia(Fila* pFila) {
    return pFila->tam == 0;
}

bool FilaEnfileira(Fila* pFila, Item item) {
    Celula* nova = (Celula*) malloc(sizeof(Celula));
    if (nova == NULL)
        return false;
    nova->prox = NULL;
    nova->item = item;
    pFila->ultimo->prox = nova;
    pFila->ultimo = nova;
    pFila->tam++;
    return true;
}

bool FilaDesenfileira(Fila* pFila, Item* pItem) {
    if (FilaEhVazia(pFila))
        return false;
    Celula* aux = pFila->primeiro->prox;
    *pItem = aux->item;
    pFila->primeiro->prox = aux->prox;
    pFila->tam--;
    free(aux);
    return true;
}

int FilaTamanho(Fila* pFila) {
    return pFila->tam;
}

void FilaImprime(Fila* pFila) {
    printf("Fila: [");
    Celula* aux = pFila->primeiro->prox;
    for (int i=0;i<pFila->tam;i++) {
        printf("(%d, %s) ", aux->item.chave, aux->item.nome);
        aux = aux->prox;
    }
    printf("]\n");
}
