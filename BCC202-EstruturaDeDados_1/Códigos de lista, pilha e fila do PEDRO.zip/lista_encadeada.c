#include "lista.h"
#include <stdlib.h>
#include <stdio.h>

typedef struct cel {
    Item info;
    struct cel* prox;
} Celula;

struct lista {
    Celula* cabeca;
    Celula* ultimo;
    int tam;
};

Lista* ListaCria() {
    Lista* lista = (Lista*) malloc(1 * sizeof(Lista));
    lista->cabeca = (Celula*) malloc(1 * sizeof(Celula));
    lista->cabeca->prox = NULL;
    lista->ultimo = lista->cabeca;
    lista->tam = 0;
    return lista;
}

void ListaDestroi(Lista** pLista) {
    Celula* aux = (*pLista)->cabeca, *aux1;
    while (aux != NULL) {
        aux1 = aux->prox;
        free(aux);
        aux = aux1;
    }
    free(*pLista);
    *pLista = NULL;
}

bool ListaEhVazia(Lista* pLista) {
    return pLista->cabeca == pLista->ultimo;
}

bool ListaInsereFinal(Lista* pLista, Item x) {
    Celula* nova = (Celula*) malloc(sizeof(Celula));
    if (nova == NULL)
        return false;
    nova->info = x;
    nova->prox = NULL;
    pLista->ultimo->prox = nova;
    pLista->ultimo = nova;
    pLista->tam++;
    return true;
}

bool ListaInsereInicio(Lista* pLista, Item x) {
    Celula* nova = (Celula*) malloc(sizeof(Celula));
    if (nova == NULL)
        return false;
    nova->info = x;
    nova->prox = pLista->cabeca->prox;
    pLista->cabeca->prox = nova;
    if (pLista->tam == 0)
        pLista->ultimo = nova;
    pLista->tam++;
    return true;
}

bool ListaRetiraFinal(Lista* pLista, Item *pX) {
    if (ListaEhVazia(pLista))
        return false;
    Celula* aux = pLista->cabeca;
    while (aux->prox != pLista->ultimo)
        aux = aux->prox;
    *pX = aux->prox->info;
    pLista->ultimo = aux;
    free(aux->prox);
    aux->prox = NULL;
    pLista->tam--;
    return true;
}

void ListaImprime(Lista* pLista) {
    printf("LISTA: [");
    Celula* aux = pLista->cabeca->prox;
    // while (aux != NULL) {
    //     printf("(%d|%s) ", aux->info.chave, aux->info.nome);
    //     aux = aux->prox;
    // }
    for (int i=0;i<pLista->tam;i++) {
        printf("(%d|%s) ", aux->info.chave, aux->info.nome);
        aux = aux->prox;
    }
    printf("]\n");
}

bool ListaGet(Lista* pLista, int p, Item *pX) {
    if (p >= ListaTamanho(pLista) || p < 0 )
        return false;
    Celula* aux = pLista->cabeca->prox;
    for (int i=0;i<p;i++)
        aux = aux->prox;
    (*pX) = aux->info;
    return true;
}

int ListaTamanho(Lista* pLista) {
    return pLista->tam;
}
