#include "fila.h"
#include "item.h"

#include <stdlib.h>
#include <stdio.h>

#define MAX_TAM 5

struct fila {
    Item itens[MAX_TAM];
    int ini, n;
};

Fila* FilaCria() {
    Fila* fila = (Fila*) malloc(sizeof(Fila));
    fila->ini = 0;
    fila->n = 0;
    return fila;
}

Fila* FilaDestroi(Fila* pFila) {
    free(pFila);
    pFila = NULL;
    return pFila;
}

bool FilaEhVazia(Fila* pFila) {
    return pFila->n == 0;
}

bool FilaEnfileira(Fila* pFila, Item item) {
    if (pFila->n == MAX_TAM)
        return false;
    int fim = (pFila->ini + pFila->n) % MAX_TAM;
    pFila->itens[fim] = item;
    pFila->n++;
    return true;
}

bool FilaDesenfileira(Fila* pFila, Item* pItem) {
    if (FilaEhVazia(pFila))
        return false;
    *pItem = pFila->itens[pFila->ini];
    pFila->ini = (pFila->ini + 1) % MAX_TAM;
    pFila->n--;
    return true;
}

int FilaTamanho(Fila* pFila) {
    return pFila->n;
}

void FilaImprime(Fila* pFila) {
    printf("Fila: [");
    int fim = pFila->ini + pFila->n;
    for (int i=pFila->ini;i<fim;i++) 
        printf("(%d, %s) ", pFila->itens[i % MAX_TAM].chave, pFila->itens[i % MAX_TAM].nome);
    printf("]\n");
}
