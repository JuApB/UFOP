#include "fila.h"
#include "item.h"

#include <stdlib.h>
#include <stdio.h>

#define MAX_TAM 5

struct fila {
    Item itens[MAX_TAM];
    int ini, n;
};

Fila* FilaCria() {
    Fila* fila = (Fila*) malloc(sizeof(Fila));
    fila->ini = 0;
    fila->n = 0;
    return fila;
}

Fila* FilaDestroi(Fila* pFila) {
    free(pFila);
    pFila = NULL;
    return pFila;
}

bool FilaEhVazia(Fila* pFila) {
    return pFila->n == 0;
}

bool FilaEnfileira(Fila* pFila, Item item) {
    if ((pFila->ini + pFila->n) == MAX_TAM)
        return false;
    pFila->itens[pFila->ini + pFila->n] = item;
    pFila->n++;
    return true;
}

bool FilaDesenfileira(Fila* pFila, Item* pItem) {
    if (FilaEhVazia(pFila))
        return false;
    *pItem = pFila->itens[pFila->ini];
    pFila->ini++;
    pFila->n--;
    return true;
}

int FilaTamanho(Fila* pFila) {
    return pFila->n;
}

void FilaImprime(Fila* pFila) {
    printf("Fila: [");
    for (int i=pFila->ini;i<pFila->ini + pFila->n;i++) 
        printf("(%d, %s) ", pFila->itens[i].chave, pFila->itens[i].nome);
    printf("]\n");
}
