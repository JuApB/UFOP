#ifndef ITEM_H
#define ITEM_H

typedef struct item {
    int chave;
    char nome[20];
} Item;

#endif // ITEM_H