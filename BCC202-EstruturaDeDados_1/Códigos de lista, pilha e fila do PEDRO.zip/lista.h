#ifndef LISTA_H
#define LISTA_H

#include <stdbool.h>

#include "item.h"

typedef struct lista Lista;

/* procedimentos e funcoes do TAD */
Lista* ListaCria();
void ListaDestroi(Lista** pLista);
bool ListaEhVazia(Lista* pLista);
bool ListaInsereFinal(Lista* pLista, Item x);
bool ListaInsereInicio(Lista* pLista, Item x);
bool ListaRetiraFinal(Lista* pLista, Item *pX);
void ListaImprime(Lista* pLista);
bool ListaGet(Lista* pLista, int p, Item *pX);
int ListaTamanho(Lista* pLista);

#endif // !LISTA_H