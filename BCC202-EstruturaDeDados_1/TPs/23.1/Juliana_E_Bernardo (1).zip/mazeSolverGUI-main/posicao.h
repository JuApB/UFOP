#ifndef POSICAO_H
#define POSICAO_H

typedef struct {
  unsigned int linha;
  unsigned int coluna;
} Posicao;

Posicao *alocarPosicoes(int);

void desalocaPosicao(Posicao *);

#endif // POSICAO_H