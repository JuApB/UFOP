#include "labirinto.h"
#include "arvore.h"
#include "percurso.h"
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int main(int argc, char *argv[]) {
  clock_t inicio, fim;
  double tempoDecorrido;

  // Marca o inicio do tempo para execucao do programa
  inicio = clock();

  No *pArvore;

  int linhas, colunas;
  char opcao;

  Labirinto *pLabirinto;

  scanf("%d %d", &linhas, &colunas);
  getc(stdin); // Para limpar a entrada
  scanf("%c", &opcao);
  getc(stdin); // Para limpar a entrada

  pLabirinto = alocarLabirinto(linhas, colunas);

  leLabirinto(pLabirinto);

  Percurso *pPercursoMenor = alocarPercurso(pLabirinto->caminhosVazios + 1);
  pPercursoMenor->tamanho = UINT_MAX;
  Percurso *pPercursoMaior = alocarPercurso(pLabirinto->caminhosVazios + 1);
  pPercursoMaior->tamanho = 0;

  bool teste = acharSaida(pLabirinto, pPercursoMenor, pPercursoMaior, &pArvore);

  // if (teste) {
  //   printf("true\n");
  // } else {
  //   printf("false\n");
  // }

  if (teste) {
    if (opcao == 'g') {
      printf("%d\n", pPercursoMaior->tamanho - 1);

      imprimePercursoNoLabirinto(pLabirinto, pPercursoMaior);
    } else if (opcao == 's') {
      printf("%d\n", pPercursoMenor->tamanho - 1);

      imprimePercursoNoLabirinto(pLabirinto, pPercursoMenor);
    } else if (opcao == 'f'){
      imprimirArvore(&pArvore);
    }
  } else {
    printf("EPIC FAIL!\n");
  }

  // printf("menor\n");
  desalocaPercurso(&pPercursoMenor);
  // printf("maior\n");
  desalocaPercurso(&pPercursoMaior);
  desalocaLabirinto(pLabirinto);
  arvoreDesaloca(&pArvore);

  // Marca o fim do tempo para execucao do programa
  fim = clock();

  tempoDecorrido = (double)(fim - inicio) / CLOCKS_PER_SEC;

  if (argc > 1) {
    if (strcmp(argv[1], "tempo") == 0) {
      printf("Tempo de execução: %.6f segundos\n", tempoDecorrido);
    }
  }

  return 0;
}
