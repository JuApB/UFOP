#include "estruturaDeDados.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

// LISTA
Lista *listaInicia() {
  Lista *pLista = (Lista *)malloc(sizeof(Lista));

  pLista->pCabeca = (Celula *)malloc(sizeof(Celula));
  pLista->pCauda = (Celula *)malloc(sizeof(Celula));

  pLista->pCabeca->pProximo = pLista->pCauda;
  pLista->pCabeca->pAnterior = NULL;

  pLista->pCauda->pProximo = NULL;
  pLista->pCauda->pAnterior = pLista->pCabeca;

  pLista->tamanho = 0;

  return pLista;
}

void listaLibera(Lista **ppLista) {
  if (!listaEhVazia(*ppLista)) {
    void *pData = NULL;

    while (!listaEhVazia(*ppLista)) {
      listaRemoveDoInicio(*ppLista, pData);
    }
  }

  free((*ppLista)->pCabeca);
  free((*ppLista)->pCauda);
  free((*ppLista));

  *ppLista = NULL;
}

bool listaEhVazia(Lista *pLista) {
  return (pLista->pCabeca->pProximo == pLista->pCauda);
}

int listaTamanho(Lista *pLista) { return pLista->tamanho; }

bool listaInsereNoInicio(Lista *pLista, No no) {
  Celula *pNovaCelula = (Celula *)malloc(sizeof(Celula));

  if (pNovaCelula == NULL) {
    return false;
  }

  pNovaCelula->no = no;

  pNovaCelula->pProximo = pLista->pCabeca->pProximo;
  pNovaCelula->pAnterior = pLista->pCabeca->pProximo->pAnterior;

  pLista->pCabeca->pProximo->pAnterior = pNovaCelula;
  pLista->pCabeca->pProximo = pNovaCelula;

  pLista->tamanho++;

  return true;
}

bool listaInsereNoFinal(Lista *pLista, No no) {
  Celula *pNovaCelula = (Celula *)malloc(sizeof(Celula));

  if (pNovaCelula == NULL) {
    return false;
  }

  pNovaCelula->no = no;

  pNovaCelula->pProximo = pLista->pCauda;
  pNovaCelula->pAnterior = pLista->pCauda->pAnterior;

  pLista->pCauda->pAnterior->pProximo = pNovaCelula;
  pLista->pCauda->pAnterior = pNovaCelula;

  pLista->tamanho++;

  return true;
}

bool listaRemoveDoInicio(Lista *pLista, No *pNo) {
  if (listaEhVazia(pLista)) {
    return false;
  }

  Celula *pAux;

  pAux = pLista->pCabeca->pProximo;

  *pNo = pAux->no;

  pAux->pProximo->pAnterior = pLista->pCabeca;
  pLista->pCabeca->pProximo = pAux->pProximo;

  free(pAux);

  pLista->tamanho--;

  return true;
}

bool listaRemoveDoFinal(Lista *pLista, No *pNo) {
  if (listaEhVazia(pLista)) {
    return false;
  }

  Celula *pAux;

  pAux = pLista->pCauda->pAnterior;

  *pNo = pAux->no;

  pAux->pAnterior->pProximo = pLista->pCauda;
  pLista->pCauda->pAnterior = pAux->pAnterior;

  free(pAux);

  pLista->tamanho--;

  return true;
}

// FILA
Lista *filaInicia() { return listaInicia(); }

void filaLibera(Lista **ppLista) { listaLibera(ppLista); }

bool filaEhVazia(Lista *pLista) { return listaEhVazia(pLista); }

int filaTamanho(Lista *pLista) { return listaTamanho(pLista); }

bool filaEnfileira(Lista *pLista, No no) {
  return listaInsereNoFinal(pLista, no);
}

bool filaDesenfileira(Lista *pLista, No *pNo) {
  return listaRemoveDoInicio(pLista, pNo);
}
