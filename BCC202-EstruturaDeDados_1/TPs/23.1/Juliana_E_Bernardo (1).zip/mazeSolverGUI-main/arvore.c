#include "arvore.h"
#include "estruturaDeDados.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

No *noCria(int linha, int coluna) {
  No *pAux = (No *)malloc(sizeof(No));

  pAux->pos.linha = linha;
  pAux->pos.coluna = coluna;

  pAux->pDireita = NULL;
  pAux->pBaixo = NULL;
  pAux->pEsquerda = NULL;
  pAux->pCima = NULL;

  return pAux;
}

void arvoreDesaloca(No **ppRaiz) {
  if (*ppRaiz == NULL) {
    return;
  }

  arvoreDesaloca(&((*ppRaiz)->pDireita));
  arvoreDesaloca(&((*ppRaiz)->pBaixo));
  arvoreDesaloca(&((*ppRaiz)->pEsquerda));
  arvoreDesaloca(&((*ppRaiz)->pCima));

  free(*ppRaiz);
}

void imprimirArvore(No **ppRaiz) {
  if (*ppRaiz == NULL)
    return;

  Lista *pFila = filaInicia();
  filaEnfileira(pFila, **ppRaiz);

  int nivel = 1;

  No noAtual;
  printf("\n");
  while (!filaEhVazia(pFila)){
    printf("Nivel %d:\n", nivel);

    int elementosNoNivel = filaTamanho(pFila);

    for (int i = 0; i < elementosNoNivel; i++){
      filaDesenfileira(pFila, &noAtual);

      printf(" (%d, %d)", noAtual.pos.linha, noAtual.pos.coluna);

      // if (noAtual.pDireita != NULL)
      //   filaEnfileira(pFila, *noAtual.pDireita);
      // if (noAtual.pBaixo != NULL)
      //   filaEnfileira(pFila, *noAtual.pBaixo);
      // if (noAtual.pEsquerda != NULL)
      //   filaEnfileira(pFila, *noAtual.pEsquerda);
      // if (noAtual.pCima != NULL)
      //   filaEnfileira(pFila, *noAtual.pCima);
      
      if (noAtual.pBaixo != NULL)
        filaEnfileira(pFila, *noAtual.pBaixo);
      if (noAtual.pCima != NULL)
        filaEnfileira(pFila, *noAtual.pCima);
      if (noAtual.pDireita != NULL)
        filaEnfileira(pFila, *noAtual.pDireita);
      if (noAtual.pEsquerda != NULL)
        filaEnfileira(pFila, *noAtual.pEsquerda);
    }
    printf("\n");
    nivel++;
  }
  filaLibera(&pFila);
}