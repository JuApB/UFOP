#ifndef ESTRUTURADEDADOS_H
#define ESTRUTURADEDADOS_H

#include "posicao.h"
#include "arvore.h"
#include <stdbool.h>

typedef struct Celula {
  No no;
  struct Celula *pProximo;
  struct Celula *pAnterior;
} Celula;

typedef struct {
  Celula *pCabeca;
  Celula *pCauda;
  int tamanho;
} Lista;

// LISTA
Lista *listaInicia();

void listaLibera(Lista **);

bool listaEhVazia(Lista *);

int listaTamanho(Lista *);

bool listaInsereNoInicio(Lista *, No);

bool listaInsereNoFinal(Lista *, No);

bool listaRemoveDoInicio(Lista *, No *);

bool listaRemoveDoFinal(Lista *, No *);

void listaImprime(Lista *);

// FILA
Lista *filaInicia();

void filaLibera(Lista **);

bool filaEhVazia(Lista *);

int filaTamanho(Lista *);

bool filaEnfileira(Lista *, No);

bool filaDesenfileira(Lista *, No *);

#endif // ESTRUTURADEDADOS_H