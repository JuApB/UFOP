#ifndef ARVORE_H
#define ARVORE_H

#include "posicao.h"
#include <stdbool.h>

typedef struct No {
  Posicao pos;
  struct No *pDireita, *pEsquerda, *pBaixo, *pCima;
} No;

typedef No *Arvore;

No *noCria(int, int);

void arvoreDesaloca(No **);

void imprimirArvore(No **);

#endif // ARVORE_H
