#include "labirinto.h"
#include "arvore.h"
#include "matriz.h"
#include "posicao.h"
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

Labirinto *alocarLabirinto(int linhas, int colunas) {
  Labirinto *pLabirinto = (Labirinto *)malloc(sizeof(Labirinto));

  pLabirinto->pMatriz = alocarMatriz(linhas, colunas);

  pLabirinto->linhas = linhas;
  pLabirinto->colunas = colunas;
  pLabirinto->caminhosVazios = 0;

  return pLabirinto;
}

void desalocaLabirinto(Labirinto *pLabirinto) {
  int linhas = pLabirinto->linhas;

  desalocarMatriz(pLabirinto->pMatriz, linhas);

  // Desaloca a estrutura labirinto
  free(pLabirinto);
}

void leLabirinto(Labirinto *pLabirinto) {
  int linhas = pLabirinto->linhas;
  int colunas = pLabirinto->colunas;

  // Saida sempre no canto inferior direito
  pLabirinto->saidaLinha = linhas - 2;
  pLabirinto->saidaColuna = colunas - 1;

  for (int i = 0; i < linhas; i++) {
    for (int j = 0; j < colunas; j++) {
      pLabirinto->pMatriz[i][j] = getc(stdin);
      if (pLabirinto->pMatriz[i][j] == ' ') {
        pLabirinto->caminhosVazios++;
      }
    }
    // Limpa o '\n' da última quebra de linha
    getc(stdin);
  }

  // Encontra a posicao incial do labirinto
  for (int i = 0; i < linhas; i++) {
    for (int j = 0; j < colunas; j++) {
      if (pLabirinto->pMatriz[i][j] == 'M') {
        pLabirinto->comecoLinha = i;
        pLabirinto->comecoColuna = j;
        return;
      }
    }
  }
}

bool ehValido(int linha, int coluna, Labirinto *pLabirinto, char **pVisitados) {

  if (linha < 0 || linha >= pLabirinto->linhas) {
    return false;
  }
  if (coluna < 0 || coluna >= pLabirinto->colunas) {
    return false;
  }

  // Verifica se é uma parede ou um ponto já visitado
  if (pLabirinto->pMatriz[linha][coluna] == '*' ||
      pVisitados[linha][coluna] == '.') {
    return false;
  }

  return true;
}

bool acharSaida(Labirinto *pLabirinto, Percurso *pPercursoMenor,
                Percurso *pPercursoMaior, No **ppArvore) {
  // Inicializa uma matriz do tamanho do labirinto,
  // sendo todas as posicoes nao vistadas
  char **pVisitados = alocarMatriz(pLabirinto->linhas, pLabirinto->colunas);

  for (int i = 0; i < pLabirinto->linhas; i++) {
    for (int j = 0; j < pLabirinto->colunas; j++) {
      pVisitados[i][j] = ' ';
    }
  }

  // Percurso a ser utilizado para o retorno da funcao acharSaida()
  // somando + 1 para evitar falha de segmentacao
  // pPercursoMenor = alocarPercurso(pLabirinto->caminhosVazios + 1);
  // pPercursoMenor->tamanho = UINT_MAX;

  // pPercursoMaior = alocarPercurso(pLabirinto->caminhosVazios + 1);
  // pPercursoMaior->tamanho = 0;

  // Percurso a ser utilizado para encontrar o menor trajeto para a saida
  // somando + 1 para evitar falha de segmentacao
  Percurso *pPercursoAux = alocarPercurso(pLabirinto->caminhosVazios + 1);
  pPercursoAux->tamanho = 0;

  *ppArvore = noCria(pLabirinto->comecoLinha, pLabirinto->comecoColuna);

  resolverLabirinto(pLabirinto, pVisitados, pPercursoMenor, pPercursoMaior,
                    pPercursoAux, ppArvore);

  // printf("menor: %u\n", pPercursoMenor->tamanho);
  // printf("maior: %d\n", pPercursoMaior->tamanho);

  desalocarMatriz(pVisitados, pLabirinto->linhas);
  desalocaPercurso(&pPercursoAux);

  if (pPercursoMenor->tamanho != UINT_MAX)
    return true;

  if (pPercursoMaior->tamanho != 0)
    return true;

  return false;
}

void resolverLabirinto(Labirinto *pLabirinto, char **pVisitados,
                       Percurso *pPercursoMenor, Percurso *pPercursoMaior,
                       Percurso *pPercursoAux, No **noAtual) {

  int linha = (*noAtual)->pos.linha;
  int coluna = (*noAtual)->pos.coluna;

  pVisitados[linha][coluna] = '.';

  pPercursoAux->pPosicoes[pPercursoAux->tamanho].linha = linha;
  pPercursoAux->pPosicoes[pPercursoAux->tamanho].coluna = coluna;
  pPercursoAux->tamanho++;

  // Copia o percurso aux para o percurso menor ou maior se a saida for
  // encontrada
  if (linha == pLabirinto->saidaLinha && coluna == pLabirinto->saidaColuna) {
    if (pPercursoAux->tamanho < pPercursoMenor->tamanho) {
      for (int i = 0; i < pPercursoAux->tamanho; i++) {
        pPercursoMenor->pPosicoes[i].linha = pPercursoAux->pPosicoes[i].linha;
        pPercursoMenor->pPosicoes[i].coluna = pPercursoAux->pPosicoes[i].coluna;
      }
      pPercursoMenor->tamanho = pPercursoAux->tamanho;
    }
    if (pPercursoAux->tamanho > pPercursoMaior->tamanho) {
      for (int i = 0; i < pPercursoAux->tamanho; i++) {
        pPercursoMaior->pPosicoes[i].linha = pPercursoAux->pPosicoes[i].linha;
        pPercursoMaior->pPosicoes[i].coluna = pPercursoAux->pPosicoes[i].coluna;
      }
      pPercursoMaior->tamanho = pPercursoAux->tamanho;
    }
  }

  // Tenta ir para DIREITA
  if (ehValido(linha, coluna + 1, pLabirinto, pVisitados)) {
    (*noAtual)->pDireita = noCria(linha, coluna + 1);
    resolverLabirinto(pLabirinto, pVisitados, pPercursoMenor, pPercursoMaior,
                      pPercursoAux, &((*noAtual)->pDireita));
  }

  // Tenta ir para BAIXO
  if (ehValido(linha + 1, coluna, pLabirinto, pVisitados)) {
    (*noAtual)->pBaixo = noCria(linha + 1, coluna);
    resolverLabirinto(pLabirinto, pVisitados, pPercursoMenor, pPercursoMaior,
                      pPercursoAux, &((*noAtual)->pBaixo));
  }

  // Tenta ir para ESQUERDA
  if (ehValido(linha, coluna - 1, pLabirinto, pVisitados)) {
    (*noAtual)->pEsquerda = noCria(linha, coluna - 1);
    resolverLabirinto(pLabirinto, pVisitados, pPercursoMenor, pPercursoMaior,
                      pPercursoAux, &((*noAtual)->pEsquerda));
  }

  // Tenta ir para CIMA
  if (ehValido(linha - 1, coluna, pLabirinto, pVisitados)) {
    (*noAtual)->pCima = noCria(linha - 1, coluna);
    resolverLabirinto(pLabirinto, pVisitados, pPercursoMenor, pPercursoMaior,
                      pPercursoAux, &((*noAtual)->pCima));
  }

  pVisitados[linha][coluna] = ' ';
  pPercursoAux->tamanho--;
}

void imprimePercursoNoLabirinto(Labirinto *pLabirinto, Percurso *pPercurso) {
  int linhas = pLabirinto->linhas;
  int colunas = pLabirinto->colunas;
  int impresso = 0;
  for (int i = 0; i < linhas; i++) {
    for (int j = 0; j < colunas; j++) {
      for (int k = 1; k < pPercurso->tamanho; k++) {
        if (i == pPercurso->pPosicoes[k].linha &&
            j == pPercurso->pPosicoes[k].coluna) {
          printf(".");
          impresso = 1;
          // k++;
        }
      }
      if (!impresso) {
        printf("%c", pLabirinto->pMatriz[i][j]);
      }
      impresso = 0;
    }
    printf("\n");
  }
}
