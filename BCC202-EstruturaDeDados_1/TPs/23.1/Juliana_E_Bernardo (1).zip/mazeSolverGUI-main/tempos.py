import os
import subprocess

# Pasta onde os arquivos .in estão localizados
pasta_teste = "tests-extra"

# Nome do arquivo executável
executavel = "./exe"

# Número mínimo de execuções para cada arquivo .in
num_execucoes = 100

# Dicionário para armazenar os tempos de execução médios
tempos_medios = {}

# Listar todos os arquivos .in na pasta de teste
arquivos_in = [arquivo for arquivo in os.listdir(pasta_teste) if arquivo.endswith(".in")]

# Loop através de cada arquivo .in
for arquivo in arquivos_in:
    tempos = []
    for _ in range(num_execucoes):
        # Executar o programa "./exe" com o arquivo .in atual
        comando = f"{executavel} < {os.path.join(pasta_teste, arquivo)} tempo"
        resultado = subprocess.run(comando, shell=True, capture_output=True, text=True)

        # Verificar se a execução produziu saída válida
        if resultado.returncode == 0:
            # Analisar o tempo de execução a partir da saída
            linhas = resultado.stdout.split("\n")
            for linha in linhas:
                if "Tempo de execução:" in linha:
                    tempo_str = linha.split(":")[-1].strip()
                    # Converter o tempo para milissegundos
                    tempo_ms = float(tempo_str.split()[0]) * 1000
                    tempos.append(tempo_ms)

    # Verificar se houve tempos de execução válidos
    if tempos:
        # Calcular a média dos tempos de execução em milissegundos
        media_tempo_ms = sum(tempos) / len(tempos)

        # Imprimir a média no terminal
        print(f"Arquivo {arquivo}:\t{media_tempo_ms:.3f} milissegundos")
