#ifndef MATRIZ_H
#define MATRIZ_H

char **alocarMatriz(int, int);

void desalocarMatriz(char **, int);


#endif // MATRIZ_H
