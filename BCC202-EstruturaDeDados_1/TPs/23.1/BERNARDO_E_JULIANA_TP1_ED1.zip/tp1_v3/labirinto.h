#ifndef LABIRINTO_H
#define LABIRINTO_H

#include "percurso.h"
#include <stdbool.h>

typedef struct labirinto Labirinto;

// Aloca um labirinto m * n
Labirinto *alocarLabirinto(int, int);

// Desaloca um labirinto m * n
void desalocaLabirinto(Labirinto *);

// Le um labirinto m * n
void leLabirinto(Labirinto *);

// Retorna o menor percurso para a saida do labirinto
Percurso *acharSaida(Labirinto *);

void resolverLabirinto(Labirinto *, char **, int, int, Percurso *, Percurso *);

// Imprime o percurso no labirinto
void imprimePercursoNoLabirinto(Labirinto *, Percurso *);

// // Imprime as posicoes visitadas no labirinto
// void imprimeVisitadosNoLabirinto(Labirinto *, char **);

#endif // LABIRINTO_H