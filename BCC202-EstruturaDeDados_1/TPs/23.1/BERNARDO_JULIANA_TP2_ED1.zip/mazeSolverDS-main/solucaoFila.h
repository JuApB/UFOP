#ifndef SOLUCAOFILA_H
#define SOLUCAOFILA_H

#include "labirinto.h"
#include "matriz.h"
#include "percurso.h"

Percurso *resolverPorBFS(Labirinto *);

#endif // SOLUCAOFILA_H