#ifndef SOLUCAOPILHA_H
#define SOLUCAOPILHA_H

#include "labirinto.h"
#include "matriz.h"
#include "percurso.h"

Percurso *resolverPorDFS(Labirinto *);

#endif // SOLUCAOPILHA_H