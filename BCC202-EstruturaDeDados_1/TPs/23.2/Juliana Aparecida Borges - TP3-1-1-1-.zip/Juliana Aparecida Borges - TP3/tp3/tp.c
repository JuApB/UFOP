#include <stdio.h>
#include <time.h>
#include <string.h>
#include "arvore.h"

int main(int argc, char *argv[]) {
    clock_t inicio, fim;
    double tempoDecorrido;

    // Marca o inicio do tempo para execucao do programa
    inicio = clock();

    int opcao;
    RBTree* arvore = NULL;

    do {
        scanf("%d", &opcao);

        int qtdDados, idadeRemover;

        switch (opcao) {
            case 1:
                scanf("%d", &qtdDados);

                for (int i = 0; i < qtdDados; i++) {
                    RBTree* novoNo = leArvore();
                    insercao(&arvore, novoNo->dado);
                }
                break;

            case 2:
                printf("Dados inOrder:\n");
                printInOrder(arvore);
                break;

            case 3:
                scanf("%d", &idadeRemover);
                remocao(&arvore, idadeRemover);
                break;

            case 0:
                // Sair do loop
                break;

            default:
                printf("Opcao invalida.\n");
        }
    } while (opcao != 0);

    printf("Dados inOrder:\n");
    printInOrder(arvore);

    // Desalocar a árvore antes de sair
    desalocarArvore(arvore);

    // Marca o fim do tempo para execucao do programa
    fim = clock();

    tempoDecorrido = (double) (fim - inicio) / CLOCKS_PER_SEC;

    if (argc > 1){
        if (strcmp(argv[1], "tempo") == 0){
        printf("Tempo de execução: %.6f segundos\n", tempoDecorrido);
        }
    }

    return 0;
}