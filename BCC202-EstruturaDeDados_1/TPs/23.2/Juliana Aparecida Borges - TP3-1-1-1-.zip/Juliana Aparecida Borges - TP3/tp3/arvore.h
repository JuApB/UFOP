#ifndef ARVORE_H
#define ARVORE_H

// Definição da estrutura Pessoa
typedef struct Pessoa {
    char nome[50];
    int idade;
} Pessoa;

// Enumeração para representar as cores dos nós na árvore rubro-negra
typedef enum {
    VERMELHO,
    PRETO
} Cores;

// Estrutura da árvore rubro-negra
typedef struct RBTree {
    Pessoa dado;
    Cores cor;  
    struct RBTree* pai;
    struct RBTree* esquerda;
    struct RBTree* direita;
} RBTree;

// Protótipos das funções
RBTree* alocarArvore(Pessoa dado);
void desalocarArvore(RBTree* arvore);
RBTree* leArvore();
void rotacaoDireita(RBTree** raiz, RBTree* x);
void rotacaoEsquerda(RBTree** raiz, RBTree* x);
void insercao(RBTree** raiz, Pessoa dado);
void remocao(RBTree** raiz, int idade);
void balanceamento(RBTree** raiz, RBTree* novoNo);
void printInOrder(RBTree* raiz);

#endif