#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arvore.h"

// Função para alocar um novo nó na árvore
RBTree* alocarArvore(Pessoa dado) {
    RBTree* novoNo = (RBTree*)malloc(sizeof(RBTree));
    if (novoNo != NULL) {
        novoNo->dado = dado;
        novoNo->cor = VERMELHO;  // Novos nós são inicialmente vermelhos
        novoNo->pai = NULL;
        novoNo->esquerda = NULL;
        novoNo->direita = NULL;
    }
    return novoNo;
}

// Função para desalocar toda a árvore
void desalocarArvore(RBTree* arvore) {
    if (arvore != NULL) {
        desalocarArvore(arvore->esquerda);
        desalocarArvore(arvore->direita);
        free(arvore);
    }
}

// Função para ler os dados de uma Pessoa e criar um novo nó na árvore
RBTree* leArvore() {
    Pessoa dado;
    scanf("%s", dado.nome);
    scanf("%d", &dado.idade);
    return alocarArvore(dado);
}

// Função para realizar a rotação à direita na árvore rubro-negra
void rotacaoDireita(RBTree** raiz, RBTree* x) {
    // Rotação à direita: x passa a ser o filho direito de y
    RBTree* y = x->esquerda;
    x->esquerda = y->direita;

    if (y->direita != NULL) {
        y->direita->pai = x;
    }

    y->pai = x->pai;

    if (x->pai == NULL) {
        *raiz = y;  // Atualiza a raiz se x era a raiz
    } else if (x == x->pai->direita) {
        x->pai->direita = y;
    } else {
        x->pai->esquerda = y;
    }

    y->direita = x;
    x->pai = y;
}

// Função para realizar a rotação à esquerda na árvore rubro-negra
void rotacaoEsquerda(RBTree** raiz, RBTree* x) {
    // Rotação à esquerda: x passa a ser o filho esquerdo de y
    RBTree* y = x->direita;
    x->direita = y->esquerda;

    if (y->esquerda != NULL) {
        y->esquerda->pai = x;
    }

    y->pai = x->pai;

    if (x->pai == NULL) {
        *raiz = y;  // Atualiza a raiz se x era a raiz
    } else if (x == x->pai->esquerda) {
        x->pai->esquerda = y;
    } else {
        x->pai->direita = y;
    }

    y->esquerda = x;
    x->pai = y;
}

// Função para realizar a inserção na árvore rubro-negra
void insercao(RBTree** raiz, Pessoa dado) {
    RBTree* novoNo = alocarArvore(dado);
    RBTree* pai = NULL;
    RBTree* atual = *raiz;

    // Localizar a posição de inserção na árvore
    while (atual != NULL) {
        pai = atual;

        if (novoNo->dado.idade < atual->dado.idade) {
            atual = atual->esquerda;
        } else {
            atual = atual->direita;
        }
    }

    // Atribuir o pai
    novoNo->pai = pai;

    // Inserir o novo nó
    if (pai == NULL) {
        *raiz = novoNo;  // Árvore estava vazia
    } else if (novoNo->dado.idade < pai->dado.idade) {
        pai->esquerda = novoNo;
    } else {
        pai->direita = novoNo;
    }

    // Realizar o balanceamento
    balanceamento(raiz, novoNo);
}

// Função para buscar um nó na árvore pelo valor da idade
RBTree* buscarNo(RBTree* raiz, int idade) {
    // Percorre a árvore em busca do nó com a idade fornecida
    while (raiz != NULL && raiz->dado.idade != idade) {
        if (idade < raiz->dado.idade)
            raiz = raiz->esquerda;
        else
            raiz = raiz->direita;
    }

    return raiz; // Retorna o nó encontrado ou NULL se não encontrado
}

// Função para encontrar o nó com o valor mínimo em uma subárvore
RBTree* minimoSubArvore(RBTree* raiz) {
    while (raiz->esquerda != NULL)
        raiz = raiz->esquerda;

    return raiz;
}

// Função para substituir um nó na árvore
void substituirNo(RBTree** raiz, RBTree* aux1, RBTree* aux2) {
    // Substitui o nó aux1 na árvore pelo nó aux2
    if (aux1->pai == NULL)
        *raiz = aux2;
    else if (aux1 == aux1->pai->esquerda)
        aux1->pai->esquerda = aux2;
    else
        aux1->pai->direita = aux2;

    if (aux2 != NULL)
        aux2->pai = aux1->pai;
}

// Função para remover um nó da árvore rubro-negra
void removerNo(RBTree** raiz, RBTree* no) {
    // Remove o nó especificado da árvore
    RBTree* y = no;
    RBTree* x;
    Cores corOriginalY = y->cor;

    // Caso 1: nó sem filho à esquerda
    if (no->esquerda == NULL) {
        x = no->direita;
        substituirNo(raiz, no, no->direita);
    } else if (no->direita == NULL) {     // Caso 2: nó sem filho à direita
        x = no->esquerda;
        substituirNo(raiz, no, no->esquerda);
    } else {     // Caso 3: nó com ambos os filhos
        // Encontra o sucessor (nó mínimo da subárvore à direita)
        y = minimoSubArvore(no->direita);
        corOriginalY = y->cor;
        x = y->direita;

        // Se o sucessor é filho direito do nó a ser removido
        if (y->pai == no) {
            if (x != NULL)
                x->pai = y;
        } else {    // Caso contrário, transferir o sucessor para a posição do nó removido
            substituirNo(raiz, y, y->direita);
            y->direita = no->direita;
            y->direita->pai = y;
        }
        // Transferir o sucessor para a posição do nó removido
        substituirNo(raiz, no, y);
        y->esquerda = no->esquerda;
        y->esquerda->pai = y;
        y->cor = no->cor; // Mantém a cor original do sucessor
    }

    // Realiza o balanceamento após a remoção
    if (corOriginalY == PRETO)
        balanceamento(raiz, x);
}

// Função para realizar a remoção de um nó na árvore rubro-negra
void remocao(RBTree** raiz, int idade) {
    RBTree* noRemover = buscarNo(*raiz, idade);

    if (noRemover == NULL) {
        printf("Idade %d nao encontrada na arvore.\n", idade);
        return;
    }

    removerNo(raiz, noRemover);
    free(noRemover);
}

// Função para realizar o balanceamento após a inserção
void balanceamento(RBTree** raiz, RBTree* novoNo) {
    // Balanceamento da árvore rubro-negra após a inserção
    RBTree* pai = NULL;
    RBTree* avo = NULL;

    // Enquanto o novo nó não é a raiz e tanto o pai quanto o avô são vermelhos
    while (novoNo != *raiz && novoNo->cor == VERMELHO && novoNo->pai->cor == VERMELHO) {
        pai = novoNo->pai;
        avo = pai->pai;

        // Caso 1: O pai é filho esquerdo do avô
        if (pai == avo->esquerda) {
            RBTree* tio = avo->direita;

            // Caso 1.1: Tio é vermelho - recoloração
            if (tio != NULL && tio->cor == VERMELHO) {
                pai->cor = PRETO;
                tio->cor = PRETO;
                avo->cor = VERMELHO;
                novoNo = avo;
            } else {  // Caso 1.2: Tio é preto - rotação e recoloração
                // Caso 1.2.1: Novo nó é filho direito - rotação à esquerda
                if (novoNo == pai->direita) {
                    rotacaoEsquerda(raiz, pai);
                    novoNo = pai;
                    pai = novoNo->pai;
                }

                // Caso 1.2.2: Rotação à direita e recoloração
                rotacaoDireita(raiz, avo);
                pai->cor = PRETO;
                avo->cor = VERMELHO;
            }
        } else {    // Caso 2: O pai é filho direito do avô
            // Lógica simétrica para o caso em que pai é filho direito do avô
            RBTree* tio = avo->esquerda;

            // Caso 2.1: Tio é vermelho - recoloração
            if (tio != NULL && tio->cor == VERMELHO) {
                pai->cor = PRETO;
                tio->cor = PRETO;
                avo->cor = VERMELHO;
                novoNo = avo;
            } else {  // Caso 2.2: Tio é preto - rotação e recoloração
                // Caso 2.2.1: Novo nó é filho esquerdo - rotação à direita
                if (novoNo == pai->esquerda) {
                    rotacaoDireita(raiz, pai);
                    novoNo = pai;
                    pai = novoNo->pai;
                }

                // Caso 2.2.2: Rotação à esquerda e recoloração
                rotacaoEsquerda(raiz, avo);
                pai->cor = PRETO;
                avo->cor = VERMELHO;
            }
        }
    }

    (*raiz)->cor = PRETO;  // A raiz sempre deve ser preta
}

// Função para imprimir os elementos da árvore em ordem
void printInOrder(RBTree* raiz) {
    if (raiz != NULL) {
        printInOrder(raiz->esquerda);
        printf("Nome: %s\nIdade: %d\n", raiz->dado.nome, raiz->dado.idade);
        printInOrder(raiz->direita);
    }
}