#ifndef GRAFO_PONDERADO_H
#define GRAFO_PONDERADO_H

// Declaração da estrutura do GrafoPonderado
typedef struct GrafoPonderado GrafoPonderado;

// Definição da estrutura do GrafoPonderado.
struct GrafoPonderado {
    int numCidades;
    int **matrizAdj;
};

GrafoPonderado *alocarGrafo(int numCidades);
void desalocarGrafo(GrafoPonderado *grafo);
void leGrafo(GrafoPonderado *grafo);
void encontraCaminho(GrafoPonderado *grafo, int *caminho, int *distancia);
void imprimeCaminho(int *caminho, int distancia, int numCidades);

#endif
