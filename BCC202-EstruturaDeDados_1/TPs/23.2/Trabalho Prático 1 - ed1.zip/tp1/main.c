#include <stdio.h>
#include <limits.h>
#include <string.h>
#include <time.h>
#include "GrafoPonderado.h"

int main(int argc, char *argv[]) {
    clock_t inicio, fim;
    double tempoDecorrido;

    // Marca o inicio do tempo para execucao do programa
    inicio = clock();

    int numCidades;
    scanf("%d", &numCidades);

    // Aloca espaço para o grafo com o número de cidades lido.
    GrafoPonderado *grafo = alocarGrafo(numCidades);
    leGrafo(grafo); // Lê as informações do grafo.

    int caminho[numCidades + 1];  // O caminho inclui a cidade inicial no final.
    int distancia;

    // Inicializa o array caminho com -1 para indicar que a cidade ainda não foi visitada.
    for (int i = 0; i <= numCidades; i++) {
        caminho[i] = -1;  
    }

    caminho[0] = 0;  // Começamos na cidade 0 (a primeira cidade).
    distancia = INT_MAX;  // Inicializa a distância com um valor máximo.

    // Encontra o caminho mínimo.
    encontraCaminho(grafo, caminho, &distancia);

    // Imprime o caminho e a distância.
    imprimeCaminho(caminho, distancia, numCidades);

    // Libera a memória alocada para o grafo.
    desalocarGrafo(grafo);

    // Marca o fim do tempo para execucao do programa
    fim = clock();

    tempoDecorrido = (double) (fim - inicio) / CLOCKS_PER_SEC;

    if (argc > 1){
        if (strcmp(argv[1], "tempo") == 0){
        printf("Tempo de execução: %.6f segundos\n", tempoDecorrido);
        }
    }

    return 0;
}