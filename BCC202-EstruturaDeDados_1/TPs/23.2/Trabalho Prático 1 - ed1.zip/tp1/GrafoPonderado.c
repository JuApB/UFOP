#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "GrafoPonderado.h"

GrafoPonderado *alocarGrafo(int numCidades) {
    // Aloca espaço para a estrutura do grafo.
    GrafoPonderado *grafo = (GrafoPonderado *)malloc(sizeof(GrafoPonderado));
    grafo->numCidades = numCidades;
    
    // Aloca espaço para a matriz de adjacência.
    grafo->matrizAdj = (int **)malloc(numCidades * sizeof(int *));
    for (int i = 0; i < numCidades; i++) {
        grafo->matrizAdj[i] = (int *)malloc(numCidades * sizeof(int));
    }
    
    return grafo;
}

void desalocarGrafo(GrafoPonderado *grafo) {
    // Libera a memória alocada para a matriz de adjacência e para a estrutura do grafo.
    for (int i = 0; i < grafo->numCidades; i++) {
        free(grafo->matrizAdj[i]);
    }
    free(grafo->matrizAdj);
    free(grafo);
}

void leGrafo(GrafoPonderado *grafo) {
    int cidadeOrigem, cidadeDestino, distanciaCity;
    
    // Lê as informações da matriz de adjacência.
    for (int i = 0; i < grafo->numCidades; i++) {
        for (int j = 0; j < grafo->numCidades; j++) {
            scanf("%d %d %d", &cidadeOrigem, &cidadeDestino, &distanciaCity);
            grafo->matrizAdj[cidadeOrigem][cidadeDestino] = distanciaCity;
        }
    }
}

// Função auxiliar recursiva para encontrar todas as permutações de cidades e calcular o menor caminho.
void encontraCaminhoRecursivo(GrafoPonderado *grafo, int cidadeAtual, int nivel, int *caminhoAtual, int *caminhoMinimo, int distanciaAtual, int *distanciaMinima, int *visitado) {
    if (nivel == grafo->numCidades) {
        // Se todas as cidades foram visitadas, adicione a distância de volta à cidade inicial
        distanciaAtual += grafo->matrizAdj[cidadeAtual][0];
        if (distanciaAtual < *distanciaMinima) {
            *distanciaMinima = distanciaAtual;
            // Copia o caminhoAtual para caminhoMinimo
            for (int i = 0; i < grafo->numCidades; i++) {
                caminhoMinimo[i] = caminhoAtual[i];
            }
            caminhoMinimo[grafo->numCidades] = 0; // Adiciona a cidade inicial ao final do caminho
        }
        return;
    }

    // Tenta todas as cidades não visitadas como o próximo passo no caminho
    for (int proximaCidade = 0; proximaCidade < grafo->numCidades; proximaCidade++) {
        if (!visitado[proximaCidade]) {
            visitado[proximaCidade] = 1;
            caminhoAtual[nivel] = proximaCidade;
            // Chama a função recursivamente com a nova cidade e a nova distância atualizada
            encontraCaminhoRecursivo(grafo, proximaCidade, nivel + 1, caminhoAtual, caminhoMinimo, distanciaAtual + grafo->matrizAdj[cidadeAtual][proximaCidade], distanciaMinima, visitado);
            visitado[proximaCidade] = 0; // Reseta o visitado para a próxima iteração
        }
    }
}

void encontraCaminho(GrafoPonderado *grafo, int *caminho, int *distancia) {
    int visitado[grafo->numCidades]; // Array para manter o controle das cidades visitadas
    int caminhoAtual[grafo->numCidades + 1]; // Array para armazenar o caminho atual
    int caminhoMinimo[grafo->numCidades + 1]; // Array para armazenar o caminho mínimo encontrado
    *distancia = INT_MAX; // Inicializa a menor distância com o maior valor inteiro possível

    // Inicializa os arrays de visitados e caminho atual
    for (int i = 0; i < grafo->numCidades; i++) {
        visitado[i] = 0;
        caminhoAtual[i] = -1;
        caminhoMinimo[i] = -1;
    }
    visitado[0] = 1; // Marca a cidade inicial como visitada
    caminhoAtual[0] = 0; // Começa o caminho pela cidade inicial

    // Chama a função recursiva para calcular o caminho mínimo
    encontraCaminhoRecursivo(grafo, 0, 1, caminhoAtual, caminhoMinimo, 0, distancia, visitado);

    // Copia o caminho mínimo para o array de caminho que será retornado
    for (int i = 0; i <= grafo->numCidades; i++) {
        caminho[i] = caminhoMinimo[i];
    }
}

// Função para imprimir o caminho mínimo encontrado e a distância total.
void imprimeCaminho(int *caminho, int distancia, int numCidades) {
    for (int i = 0; i <= numCidades; i++) {
        printf("%d ", caminho[i]);
    }
    printf("\n%d\n", distancia);
}