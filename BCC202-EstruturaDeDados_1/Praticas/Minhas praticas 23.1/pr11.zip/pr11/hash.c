#include "hash.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Manter como especificado
void inicia (Hash *hash, int m, int p) {
    hash->tamanho = m;
    hash->pesos = (int*)malloc(p * sizeof(int));
    for (int i = 0; i < p; i++) {
        scanf("%d", &hash->pesos[i]);
    }

    hash->tabela = (Aluno*)malloc(m * sizeof(Aluno));
    for (int i = 0; i < m; i++) {
        hash->tabela[i].nome[0] = '\0';
    }
}

// Manter como especificado
void libera(Hash *hash) {
    // preencher aqui
    free(hash->tabela);
    free(hash->pesos);
}

// Manter como especificado
int H(Hash* hash, Aluno aluno) {
    // preencher aqui 

    int h1 = 0, h2 = 0, resposta = 0;
    int nome_len = (strlen(aluno.nome) - 1);
    
    for (int i = 0; i < (nome_len); i++) {
        h1 += (aluno.nome[i] * (hash->pesos[i % hash->tamPesos]));
    }

    for (int i = 0; i < 7; i++) {
        h2 += aluno.matricula - '0';
    }
    
    resposta = (h1+h2) % hash->tamanho;
    return resposta; 
}

// Manter como especificado
bool insere (Hash *hash, Aluno aluno) {
    // preencher aqui
    int chaveH = H(hash, aluno);
    
    while (hash->tabela[chaveH].nome[0] != '\0') {
        chaveH = (chaveH + 1) % hash->tamanho;
    }

    hash->tabela[chaveH] = aluno;
    return true;

}

// Manter como especificado
void imprime(Hash* hash) {
    // preencher aqui
    for (int i = 0; i < hash->tamanho; i++) {
        if (hash->tabela[i].nome[0] != '\0') {
            printf("[%d] %s - %d (%.1f)\n", hash->tabela[i].matricula, hash->tabela[i].nome, hash->tabela[i].idade, hash->tabela[i].peso);
        }
    }
}
