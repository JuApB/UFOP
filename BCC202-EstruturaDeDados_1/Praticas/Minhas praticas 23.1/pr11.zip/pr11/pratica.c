#include <stdio.h>
#include <stdlib.h>

#include "hash.h"


int main() {
    Hash hash;
    int n;
    scanf("%d", &n);

    int p;
    scanf("%d", &p);

    hash.tamPesos = p;
    inicia(&hash, n, p);

    for (int i = 0; i < n; i++) {
        Aluno aluno;
        scanf("%s %d %d %f", aluno.nome, &aluno.matricula, &aluno.idade, &aluno.peso);
        insere(&hash, aluno);
    }

    imprime(&hash);

    libera(&hash);
    return 0;
}