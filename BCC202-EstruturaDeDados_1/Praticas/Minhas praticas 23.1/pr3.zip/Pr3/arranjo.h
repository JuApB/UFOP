#ifndef ARRANJO_H
#define ARRANJO_H

typedef struct arranjo Arranjo;

// Manter como especificado
void leinfo(int*, int*);

// Manter como especificado
Arranjo* cria(int, int);

// Manter como especificado
void libera(Arranjo**);

// Manter como especificado
void imprime(Arranjo*, int);

#endif // ARRANJO_H