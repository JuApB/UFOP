#include "arranjo.h"

#include <stdlib.h>
#include <stdio.h>

struct arranjo {
    int* v;
    int n;
    int k;
};

// Coloca o elemento na posicao p2 na posicao p1
// e arrasta todos os elementos de p1 em diante para a direita
void move(Arranjo* pArranjo, int p1, int p2) {
    int aux = pArranjo->v[p2];
    for (int i=p2-1;i>=p1;i--) {
        pArranjo->v[i+1] = pArranjo->v[i];
    }
    pArranjo->v[p1] = aux;
}

// Volta o vetor para a ordem original
void moveBack(Arranjo* pArranjo, int p1, int p2) {
    int aux = pArranjo->v[p1];
    for (int i=p1+1;i<=p2;i++) {
        pArranjo->v[i-1] = pArranjo->v[i];
    }
    pArranjo->v[p2] = aux;
}

void leinfo(int* pN, int* pK) {
    scanf("%d %d", pN, pK);
}

void imprimeArranjo(Arranjo* pArranjo) {
    for (int i=0;i<pArranjo->k; i++)
        printf("%d ", pArranjo->v[i]); 
    printf("\n");
}

Arranjo* cria(int n, int k) {
    Arranjo* pArranjo = (Arranjo*) malloc(sizeof(Arranjo));
    pArranjo->v = (int*) malloc(sizeof(int) * k);
    pArranjo->n = n;
    pArranjo->k = k;
    for (int i=0;i<k;i++)
        pArranjo->v[i] = i+1;
    return pArranjo;
}

void libera(Arranjo** pArranjo) {
    free((*pArranjo)->v);
    free(*pArranjo);
    *pArranjo = NULL;
}

void imprime(Arranjo* pArranjo, int index) {
    if (index == pArranjo->k) {
        imprimeArranjo(pArranjo);
    }
    else {
        for (int i=index;i< pArranjo->n;i++) {
            move(pArranjo, index, i);
            imprime(pArranjo, index+1);
            moveBack(pArranjo, index, i);   
        }
    }
}