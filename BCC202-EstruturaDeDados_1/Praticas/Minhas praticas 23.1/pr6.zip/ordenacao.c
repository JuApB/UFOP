#include "ordenacao.h"

#include <stdlib.h>
#include <string.h>

// Manter como especificado
Pessoa *alocaVetor(int n) {
    Pessoa *vetor = (Pessoa *) malloc(n* sizeof(Pessoa));
    return vetor;
}

// Manter como especificado
void desalocaVetor(Pessoa **vetor) {
    free(*vetor);
    *vetor = NULL;
}

// implemente sua funcao do mergesort, que deve invocar a funcao merge
void MergeSort(Pessoa *vetor, int esquerda, int direita)
{
   if (esquerda < direita) {
        int meio = esquerda + (direita - esquerda) / 2;
 
        // Ordenar primeira e segunda metades
        MergeSort(vetor, esquerda, meio);
        MergeSort(vetor, meio + 1, direita);
 
        merge(vetor, esquerda, meio, direita);
    }
}

// implemente sua funcao do mergesort, que deve invocar a funcao merge
void merge(Pessoa *vetor, int esquerda, int meio, int direita)
{
    int i, j, k;
    int n1 = meio - esquerda + 1;
    int n2 = direita - meio;

    Pessoa* vEsq = alocaVetor(n1);
    Pessoa* vDirei = alocaVetor(n2);
 
    // Copiar dados para vetores temporários vEsq[] e vDirei[]
    for (i = 0; i < n1; i++)
        vEsq[i] = vetor[esquerda + i];

    for (j = 0; j < n2; j++)
        vDirei[j] = vetor[meio + 1 + j];
 
    i = 0;
    j = 0;
    k = esquerda;

    while (i < n1 && j < n2) {
        int comparacao = strcmp(vEsq[i].nome, vDirei[j].nome);
        if (comparacao < 0 || (comparacao == 0 && vEsq[i].idade <= vDirei[j].idade)) {
            vetor[k] = vEsq[i];
            i++;
        }
        else {
            vetor[k] = vDirei[j];
            j++;
        }
        k++;
    }
 
    // Copia os elementos restantes de vEsq[],
    // se houver algum
    while (i < n1) {
        vetor[k] = vEsq[i];
        i++;
        k++;
    }
 
    // Copia os elementos restantes de vDirei[],
    // se houver algum
    while (j < n2) {
        vetor[k] = vDirei[j];
        j++;
        k++;
    }

    desalocaVetor(&vEsq);
    desalocaVetor(&vDirei);
}