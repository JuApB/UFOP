#include "ordenacao.h"

#include <stdio.h>
#include <stdlib.h>

struct pacote {
    char name[51];
    int code;
    float weight; //peso
};

void swap(Pacote*, Pacote*);
int partition(Pacote*, int, int);
void quick(Pacote*, int, int);

// Manter como especificado
Pacote *alocaVetor(int n) {
    Pacote *pacotes = (Pacote *) malloc(n* sizeof(Pacote));
    return pacotes;
}

// Manter como especificado
void desalocaVetor(Pacote** pacotes) {
    free(*pacotes);
    *pacotes = NULL;
}

// Manter como especificado
void lePacotes(Pacote* pacotes, int n) {
    // para cada pacote...
    for (int i = 0; i < n; i++) {
            // preencher o vetor de pacote...
            scanf("%s", pacotes[i].name);
            scanf("%d", &pacotes[i].code);
            scanf("%f", &pacotes[i].weight);
        }
    
}

// Manter como especificado
void ordenarPacotes(Pacote* pacotes, int n) {
    quick(pacotes, 0, n - 1);
}

// Manter como especificado
void imprimirPacotes(Pacote* pacotes, int n) {
	for (int i = 0; i < n; i++)
		printf("%s %d %.1f\n", pacotes[i].name, pacotes[i].code, pacotes[i].weight);

    printf("\n");
}

// Manter como especificado
void swap(Pacote* a, Pacote* b) {
    Pacote aux;
    aux = *a;
	*a = *b;
	*b = aux;
}

// Manter como especificado
int partition(Pacote* pacotes, int p, int r) {
    int i = p - 1;
    Pacote pivo = pacotes[r]; //escolhendo o pivo

    for (int j = p; j <= r - 1; j++) {
        if (pacotes[j].weight < pivo.weight || (pacotes[j].weight == pivo.weight && pacotes[j].code < pivo.code)) {
            i++;
            swap(&pacotes[i], &pacotes[j]);
        }
    }
    swap(&pacotes[i + 1], &pacotes[r]);

    return i + 1;
}

// Manter como especificado
void quick(Pacote* pacotes, int p, int r) {
    if (p < r) {

		// iPartic é o índice de particionamento, pacotes[]
		// agora está no lugar certo
		int iPartic = partition(pacotes, p, r);

        // Classifique os elementos separadamente antes
        // partição e depois da partição
		quick(pacotes, p, iPartic - 1);
		quick(pacotes, iPartic + 1, r);

	}

}
