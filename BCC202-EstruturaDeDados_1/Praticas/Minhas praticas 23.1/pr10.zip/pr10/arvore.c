#include "arvore.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Manter como especificado
void TArvoreInicia (TNo **pRaiz){
  //PREENCHER AQUI
  *pRaiz = NULL;
}

//Manter como especificado
int TArvoreInsere (TNo **ppRaiz, TItem x){
  //PREENCHER AQUI
  TNo **ppAux;
  ppAux = ppRaiz;

  while (*ppAux != NULL) {
      if (strcmp(x.chave, (*ppAux)->item.chave) < 0)
          ppAux = &((*ppAux)->pEsq);
      else if (strcmp(x.chave, (*ppAux)->item.chave) > 0)
          ppAux = &((*ppAux)->pDir);
      else{
          (*ppAux)->item.contador++;
          return 0;
      }
   }
   *ppAux = TNoCria(x);
    return 1;
}

//Manter como especificado
TNo *TNoCria (TItem x){
  //PREENCHER AQUI
    TNo *pAux = (TNo*) malloc(sizeof(TNo));
    pAux->item = x;
    strcpy(pAux->item.chave, x.chave);
    pAux->item.contador = 1;
    pAux->pEsq = NULL;
    pAux->pDir = NULL;
    return pAux;
}

// realizar o caminhamento adequado na arvore
// Manter como especificado
void caminhamento(TNo *p) {
  //PREENCHER AQUI
  if(p == NULL)
    return;
  
  caminhamento(p->pEsq);
  printf("%s %d\n", p->item.chave, p->item.contador);
  caminhamento(p->pDir);
}
