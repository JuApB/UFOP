#include "avl.h"
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

void inicia(No** ppRaiz) {
    *ppRaiz = NULL;
}

void libera(No** ppRaiz) {
    if (*ppRaiz != NULL) {
        libera(&((*ppRaiz)->pEsq));
        libera(&((*ppRaiz)->pDir));
        free(*ppRaiz);
        *ppRaiz = NULL;
    }
}

bool insere(No** ppRaiz, Item x) {
    No **ppAux;
    ppAux = ppRaiz;
    
    while(*ppAux != NULL){
        if(compara((*ppAux)->item, x) == MAIOR) {
            if (insere(&((*ppAux)->pEsq), x)) {
                if (Balanceamento(ppAux))
                    return false;
                else
                    return true;
            }
            else    
                return false;
        } 
        else if (compara((*ppAux)->item, x) == MENOR) {
            if (insere(&((*ppAux)->pDir), x)) {
                if (Balanceamento(ppAux))
                    return false;
                else
                    return true;
            }    
            else
                return false;
        } 
        else {
            (*ppAux)->cont++;

            return false;
        }
    }

    *ppAux = criaNo(x);
    return true;
}

No *criaNo(Item x) {
    No* novoNo = (No*)malloc(sizeof(No));

    novoNo->item = x;
    strcpy(novoNo->item.chave, x.chave);
    novoNo->cont = 1;
    novoNo->pEsq = NULL;
    novoNo->pDir = NULL;

    return novoNo;
}

void caminhamento(No *pNo) {
    if(pNo == NULL)
        return;
    
    caminhamento(pNo->pEsq);
    printf("%s %d\n", pNo->item.chave, pNo->cont);
    caminhamento(pNo->pDir);
}

RELACAO compara(const Item item1, const Item item2) {
    int response = strcmp(item1.chave, item2.chave);
    if (response < 0)
        return MENOR;
    else if (response > 0)
        return MAIOR;
    return IGUAL;
}

int FB(No *pRaiz) {
    return (pRaiz == NULL) ? 0 : altura(pRaiz->pEsq) - altura(pRaiz->pDir);
}

int altura(No *pRaiz) {
    int iEsq, iDir;
    if(pRaiz == NULL)
        return 0;
    iEsq = altura(pRaiz->pEsq);
    iDir = altura(pRaiz->pDir);
    if(iEsq > iDir)
        return iEsq + 1;
    else
        return iDir + 1;
}

void RSE(No **ppRaiz) {
    No *pAux;
    pAux = (*ppRaiz)->pDir;
    (*ppRaiz)->pDir = pAux->pEsq;
    pAux->pEsq = (*ppRaiz);
    (*ppRaiz) = pAux;
}

void RSD(No **ppRaiz) {
    No *pAux;
    pAux = (*ppRaiz)->pEsq;
    (*ppRaiz)->pEsq = pAux->pDir;
    pAux->pDir = (*ppRaiz);
    (*ppRaiz) = pAux;
}

int BalancaEsquerda(No **ppRaiz) {
    int fbe = FB((*ppRaiz)->pEsq);
    if (fbe >= 0) {
        RSD(ppRaiz);
        return 1;
    } else if (fbe <= 0) {
        RSE(&((*ppRaiz)->pEsq));
        RSD(ppRaiz);
        return 1;
    }
    return 0;
}

int BalancaDireita(No **ppRaiz) {
    int fbd = FB((*ppRaiz)->pDir);
    if (fbd <= 0) {
        RSE(ppRaiz);
        return 1;
    } else {
        RSD(&((*ppRaiz)->pDir));
        RSE(ppRaiz);
        return 1;
    }
    return 0;
}

int Balanceamento(No **ppRaiz) {
    int fb = FB(*ppRaiz);
    if (fb > 1)
        return BalancaEsquerda(ppRaiz);
    else if (fb < -1)
        return BalancaDireita(ppRaiz);

    return 0;
}
