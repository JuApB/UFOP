#include "lista.h"

#include <stdlib.h>
#include <stdio.h>

Lista *ListaInicia() {
    //Lista* lista = (Lista*)malloc(sizeof(struct lista));

    Lista* lista = (Lista*) malloc(sizeof(Lista));
    lista->cabeca = (Celula*) malloc(sizeof(Celula));
    lista->cauda = (Celula*) malloc(sizeof(Celula));

    lista->cabeca->prox = lista->cauda;
    lista->cabeca->anterior = NULL;
    lista->cauda->anterior = lista->cabeca;
    lista->cauda->prox = NULL;
    lista->tamanho = 0;

    return lista;
}

void ListaLibera(Lista **ppLista) {
    if(ppLista != NULL && *ppLista != NULL){
        Celula *pAtual = (*ppLista)->cabeca->prox;
        while(pAtual != (*ppLista)->cauda){
            Celula *pProx = pAtual->prox;
            free(pAtual);
            pAtual = pProx;
        }
        free((*ppLista)->cabeca);
        free((*ppLista)->cauda);
        free(*ppLista);
        *ppLista = NULL;
    }
}

void ListaTroca(Lista* lista, int p1, int p2) {
    // Validar posicoes p1 e p2 
    if(p1 < 0 || p2 < 0 || p1 >= lista->tamanho || p2 >= lista->tamanho)
        return;

    Celula *ptrP1 = lista->cabeca;
    Celula *ptrP2 = lista->cabeca;
    if(p1 < p2){
        for(int i = 0; i < p1; i++){
            ptrP1 = ptrP1->prox;
        }
    } else if(p1 > p2){
        for(int i = 0; i < p2; i++){
            ptrP2 = ptrP2->prox;
        }
    }

    ptrP1->prox->anterior = ptrP2;
    ptrP2->prox->anterior = ptrP1;
    ptrP1->anterior->prox = ptrP2;
    ptrP2->anterior->prox = ptrP1;

    //troca os ponteiros
    Celula *p1Anterior = ptrP1->anterior;
    Celula *p1Proximo = ptrP1->prox;
    Celula *p2Anterior = ptrP2->anterior;
    Celula *p2Proximo = ptrP2->prox;

    ptrP2->anterior = p1Anterior;
    ptrP2->prox = p1Proximo;

    ptrP1->anterior = p2Anterior;
    ptrP1->prox = p2Proximo;

}

void ListaLe(Lista *pLista, int n) {
    Aluno aluno;
    for (int i=0;i<n;i++) {
        scanf("%s %f %s", aluno.nome, &aluno.coeficiente, aluno.matricula);
        ListaInsereNoFinal(pLista, aluno);
    }
}

int ListaTamanho(Lista *pLista) {
    return pLista->tamanho;
}

bool ListaInsereNoFinal(Lista *pLista, Aluno aluno) {
    Celula *novaCelula = NULL;
    novaCelula = (Celula*) malloc(sizeof(Celula));

    if(novaCelula == NULL){
        return false;
    }

    novaCelula->aluno = aluno;
    novaCelula->prox = pLista->cauda;
    novaCelula->anterior = pLista->cauda->anterior;
    pLista->cauda->anterior->prox = novaCelula;
    pLista->cauda->anterior = novaCelula;
    pLista->tamanho++;
    return true;
}