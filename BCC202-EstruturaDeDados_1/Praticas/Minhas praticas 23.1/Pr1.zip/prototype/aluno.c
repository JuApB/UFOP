#include "aluno.h"

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct aluno {
  char* nome;
  char curso;
  float nota;
};

struct turma {
  char* alunos; // vetor de ponteiro de alunos
  int nTurma; // inteiro com o tamanho da turma
};

// Manter como especificado
void lerInfos(int *qtd, char *option) {
  scanf("%s", option);
  scanf("%d", qtd);
}

// Manter como especificado
Aluno* alocaAluno(int qtd) {
   struct aluno *dados = malloc (qtd * sizeof(aluno));
   

// Manter como especificado
Turma* alocaTurma(int quantidadeDeAlunos) {
  // Use a funcao alocaAluno aqui
  *alocaAluno 
  struct turma *info = malloc (quantidadeDeAlunos * sizeof(turma));
}

// Manter como especificado
void desalocaAluno(Aluno **pAluno) {
  free(dados);
}
}

// Manter como especificado
void desalocaTurma(Turma **pTurma) {
  // Use a funcao desalocaTurma
  free(info);
}

// Manter como especificado
void lerTurma(Turma *pTurma) {
  
}

// Manter como especificado
float calcularMetrica(Turma *pTurma, char* curso, char option) {
  
}

// Manter como especificado
void printMetrica(char* curso, float metrica, char option) {
  printf("A %s no curso de %s eh %.1f\n", option == 'S' ? "soma" : "media", curso, metrica);
}
