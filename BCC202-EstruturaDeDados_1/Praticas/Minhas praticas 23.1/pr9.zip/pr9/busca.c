#include "busca.h"

#include <stdio.h>
#include <stdlib.h>

int* aloca(int n) {
    int* v = (int*)malloc(n * sizeof(int));
    return v;
}

void desaloca(int** v) {
    free(*v);
    *v = NULL;
}

void le(int* v, int n) {
    for (int i = 0; i < n; i++) {
        scanf("%d", &v[i]);
    }
}

// Função de busca sequencial
int buscaSequencial(int v[], int n, int X, int *comparacoes) {
    for (int i = 0; i < n; i++) {
        (*comparacoes)++; // Incrementar a contagem de comparações

        if (v[i] == X) {
            return i; // Elemento encontrado, retornar o índice
        }
    }

    return -1; // Elemento não encontrado, retornar -1
}

// Função de ordenação Quick Sort
void quickSort(int v[], int esq, int dir) {
    if (esq >= dir) {
        return;
    }

    int pivo = v[dir];
    int i = esq - 1;

    for (int j = esq; j < dir; j++) {
        if (v[j] <= pivo) {
            i++;
            int temp = v[i];
            v[i] = v[j];
            v[j] = temp;
        }
    }

    int temp = v[i + 1];
    v[i + 1] = v[dir];
    v[dir] = temp;

    int indiceDeParticao = i + 1;

    quickSort(v, esq, indiceDeParticao - 1);
    quickSort(v, indiceDeParticao + 1, dir);
}

// Função de busca binária
int buscaBinaria(int v[], int esq, int dir, int X, int *comparacoes) {
    while (esq <= dir) {
        int meio = esq + (dir - esq) / 2;
        (*comparacoes)++; // Incrementar a contagem de comparações

        if (v[meio] == X) {
            return meio; // Elemento encontrado, retornar o índice
        } else if (v[meio] < X) {
            esq = meio + 1; // Procurar na metade direita do vetor
        } else {
            dir = meio - 1; // Procurar na metade esquerda do vetor
        }
    }

    return -1; // Elemento não encontrado, retornar -1
}