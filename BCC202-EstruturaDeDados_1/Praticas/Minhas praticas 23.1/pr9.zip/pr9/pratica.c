#include <stdio.h>
#include <stdlib.h>

#include "busca.h"

int main() {
    int M; // número de casos de teste
    scanf("%d", &M);

    while (M--) {
        int X; // número a ser buscado
        int N; // quantidade de números no vetor
        scanf("%d %d", &X, &N);

        int* v = aloca(N);

        le(v, N);

        int comparacoesSeq = 0; // Variável para contar as comparações na busca sequencial
        int comparacoesBin = 0; // Variável para contar as comparações na busca binária

        // Realizar a busca sequencial e obter o índice do elemento (se encontrado)
        buscaSequencial(v, N, X, &comparacoesSeq);

        // Ordenar o vetor antes da busca binária
        quickSort(v, 0, N - 1);

        // Realizar a busca binária e obter o índice do elemento (se encontrado)
        buscaBinaria(v, 0, N - 1, X, &comparacoesBin);

        printf("%d %d\n", comparacoesSeq, comparacoesBin);
        //printf("Quantidade de comparacoes na busca binaria: %d\n", comparisonsBinary);

        desaloca(&v);
    }

    return 0;
}
