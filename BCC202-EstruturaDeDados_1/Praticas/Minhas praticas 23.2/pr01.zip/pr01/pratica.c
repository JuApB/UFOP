#include <stdio.h>

#define TAM 12

int main() {
    double t = 0.0, s = 0.0, M[TAM][TAM];
    char T;
    int i, j, total = 0;

    // Leitura do Char
    scanf("%c", &T);

    // Leitura da Matriz e Cálculos
    for (i = 0; i < TAM; i++) {
        for (j = 0; j < TAM; j++) {
            scanf("%lf", &M[i][j]);
        }
    }

    // Cálculo da Soma ou Média na área superior da matriz
    for (i = 0; i < TAM; i++) {
        for (j = 0; j < TAM; j++) {
            if (i < j && i + j < 11) { // Verifica se o elemento está na área superior da matriz
                s += M[i][j];
                total++;
            }
        }
    }

    // Impressão dos resultados
    if (T == 'M') {
        t = s / total; 
        printf("%.1lf\n", t);
    } else if (T == 'S'){
        printf("%.1lf\n", s);
    }

    return 0;
}
