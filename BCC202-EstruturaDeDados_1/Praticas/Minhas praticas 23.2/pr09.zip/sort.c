#include "sort.h"
#include "pilha.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct paciente {
    char nome[51];
	int idade;
	int estado;
};

// Manter como especificado
int partition(Paciente*, int, int);

// Manter como especificado
void troca(Paciente*, Paciente*);

// Manter como especificado
void alocarPacientes(Upa* upa, int n) {
    upa->pacientes = (Paciente *)malloc(n * sizeof(Paciente));
    upa->n = n;
}

// Manter como especificado
void desalocarPacientes(Upa* upa) {
    free(upa->pacientes);
}

// Manter como especificado
void lePacientes(Upa* upa) {
    for (int i = 0; i < upa->n; i++) {
        scanf("%s %d %d", upa->pacientes[i].nome, &upa->pacientes[i].idade,
              &upa->pacientes[i].estado);
    }
}

// Manter como especificado
void imprimeUpa(Upa* upa) {
    for (int i = 0; i < upa->n; i++)
        printf("%s %d %d\n", upa->pacientes[i].nome, upa->pacientes[i].idade,
            upa->pacientes[i].estado);
}

// Manter como especificado
void ordena(Upa* upa) {
    Pilha *pPilha = PilhaCria();
    int p = 0, r = (upa->n - 1);

    PilhaPush(pPilha, p, r);

    while(!PilhaEhVazia(pPilha)){
        PilhaPop(pPilha, &p, &r);

        if(p < r){
            int j;
            j = partition(upa->pacientes, p, r);
            PilhaPush(pPilha, p, j-1);
            PilhaPush(pPilha, j+1, r);
            } 
    }
    PilhaDestroi(pPilha);
}

// Manter como especificado
int partition(Paciente* pacientes, int p, int r) {
    int i = p - 1;
    Paciente x = pacientes[r];

    for(int j = p; j < r; j++){
        if(pacientes[j].estado > x.estado){
            i = i + 1;
            troca(&pacientes[i], &pacientes[j]);
        } else if(pacientes[j].estado == x.estado){
            if (pacientes[j].idade > x.idade) {
                i = i + 1;
                troca(&pacientes[i], &pacientes[j]);
            } else if(pacientes[j].idade == x.idade){
                if (strcmp(pacientes[j].nome, x.nome) < 0){
                    i = i + 1;
                    troca(&pacientes[i], &pacientes[j]);
                }
            }
        }
    }
    troca(&pacientes[i+1], &pacientes[r]);

    return i + 1;
}

// Manter como especificado
void troca(Paciente* p1, Paciente* p2) {
    Paciente aux = *p1;
    *p1 = *p2;
    *p2 = aux;
}