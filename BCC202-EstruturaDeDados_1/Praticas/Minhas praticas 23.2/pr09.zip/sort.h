#ifndef HEAP_H
#define HEAP_H

typedef struct paciente Paciente;

typedef struct {
    Paciente* pacientes;
    int n;
} Upa;

// Manter como especificado
void alocarPacientes(Upa*, int);

// Manter como especificado
void desalocarPacientes(Upa*);

// Manter como especificado
void lePacientes(Upa*);

// Manter como especificado
void imprimeUpa(Upa*);

// Manter como especificado
void ordena(Upa*);

#endif // HEAP_H