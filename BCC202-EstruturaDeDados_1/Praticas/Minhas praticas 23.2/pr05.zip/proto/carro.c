#include "carro.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

struct funcionario {
    char nome[20];
    int matricula;
};

struct carro {
    int numChassi;
    char marca[20];
    int qtdLugares;
    int anoFabricacao;
    Funcionario* func;
};

Funcionario* FuncionarioAloca() {
    Funcionario* funcionario = (Funcionario*) malloc(sizeof(Funcionario));
    return funcionario;
}

void FuncionarioDesaloca(Funcionario** func) {
    free(*func);
    *func = NULL;
}

Carro* CarroAloca(int n) {
    Carro* carro = (Carro*) malloc(n * sizeof(Carro));
    for(int i = 0; i < n; i++){
        carro[i].func = FuncionarioAloca();
    }
    return carro;
}

void CarroDesaloca(Carro** carros, int n) {
    for(int i = 0; i < n; i++){
        FuncionarioDesaloca(&(*carros)[i].func);
    }
    free(*carros);
    *carros = NULL;
}

void le(Carro* carros, int n) {
    for(int i = 0; i < n; i++){
        scanf("%d %s %d %d", &carros[i].numChassi, carros[i].marca, &carros[i].qtdLugares, &carros[i].anoFabricacao);
        scanf("%s %d", carros[i].func->nome, &carros[i].func->matricula);
    }
}

int conta(Carro* carros, int n, const int ano, const int lugares) {   
    if(n <= 0){
        return 0;
    }   

    if(carros[n-1].anoFabricacao > ano && carros[n-1].qtdLugares > lugares){
        return 1 + conta(carros, n-1, ano, lugares);
    } else {
        return conta(carros, n-1, ano, lugares);
    }
}

void imprime(Carro* carros, int n, const char* nome) {
    if (n <= 0) {
        return;
    }
    if (strcmp(carros[n-1].func->nome, nome) == 0) {
        printf("%s [%d|%d|%d]\n", carros[n-1].marca, carros[n-1].anoFabricacao, carros[n-1].qtdLugares, carros[n-1].numChassi);
    }
    imprime(carros, n-1, nome);
}
