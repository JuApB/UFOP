#include "lista.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Inicia as variaveis da lista
void TLista_Inicia(TLista *pLista) {
//semelhante ao visto em aula
    pLista->primeiro = NULL;
    pLista->ultimo = NULL;
}

//Retorna se a lista esta vazia
int TLista_EhVazia(TLista *pLista) {
//semelhante ao visto em aula
    return (pLista->primeiro == NULL);
}

// Insere um item no final da lista
int TLista_InsereFinal(TLista *pLista, TItem x) {
//semelhante ao visto em aula
    TCelula *novo = (TCelula*)malloc(sizeof(TCelula));
    if (novo == NULL) {
        return 0; // Falha na alocação de memória
    }

    novo->item = x;
    novo->prox = NULL;

    if (TLista_EhVazia(pLista)) {
        pLista->primeiro = novo;
        pLista->ultimo = novo;
    } else {
        pLista->ultimo->prox = novo;
        pLista->ultimo = novo;
    }

    return 1; // Inserção realizada com sucesso

    /*TCelula *novo = (TCelula*)malloc(sizeof(TCelula));
    novo->item = x;
    novo->prox = NULL;
    if (TLista_EhVazia(pLista)) {
        pLista->primeiro = novo;
        pLista->ultimo = novo;
    } else {
        pLista->ultimo->prox = novo;
        pLista->ultimo = novo;
    }*/
}

// Retira o primeiro item da lista
int TLista_RetiraPrimeiro(TLista *pLista, TItem *pX) {
//semelhante ao visto em aula
    if(TLista_EhVazia(pLista))
        return 0;

    TCelula *aux = pLista->primeiro;
    *pX = aux->item;

    pLista->primeiro = aux->prox;
    free(aux);

    if (pLista->primeiro == NULL) {
        pLista->ultimo = NULL;
    }

    return 1; // Retirada realizada com sucesso
    
    /*if(TLista_EhVazia(pLista))
        return 0;

    TCelula *aux;
    aux = pLista->primeiro->prox;
    *pX = aux->item;
    pLista->primeiro->prox = aux->prox;
    free(aux);
    return 1;*/
}

// Imprime os elementos da lista
void TLista_Imprime(TLista *pLista) {
//semelhante ao visto em aula
    TCelula *atual = pLista->primeiro;
    while (atual != NULL) {
        printf("%s ", atual->item.nome);
        atual = atual->prox;
    }
    printf("\n");
}

//Remove cada elemento de uma lista e libera a memória
void TLista_Esvazia(TLista *pLista) {
//preencher
    TItem x;
    while (TLista_RetiraPrimeiro(pLista, &x)); // Esvazia a lista
}

// Acrescenta o conteudo de uma lista ao final de outra, apenas manipulando ponteiros
void TLista_append(TLista *pLista1, TLista *pLista2){
//preencher
    if (TLista_EhVazia(pLista2)) {
        return; // Lista2 está vazia, não há o que acrescentar
    }

    if (TLista_EhVazia(pLista1)) {
        *pLista1 = *pLista2;
    } else {
        pLista1->ultimo->prox = pLista2->primeiro;
        pLista1->ultimo = pLista2->ultimo;
    }

    // Limpar a lista2 após a operação
    TLista_Inicia(pLista2);
}

// Inclui o conteudo de uma lista em outra, na posicao anterior a str, apenas manipulando ponteiros
void TLista_include(TLista *pLista1, TLista *pLista2, char *str){
//preencher
    TCelula *atual = pLista1->primeiro;
    TCelula *ant = NULL;

    while (atual != NULL && strcmp(atual->item.nome, str) != 0) {
        ant = atual;
        atual = atual->prox;
    }

    if (atual != NULL) {
        if (ant == NULL) {
            // Inclusão no início
            TLista_append(pLista2, pLista1);
            *pLista1 = *pLista2;
        } else {
            ant->prox = pLista2->primeiro;
            pLista2->ultimo->prox = atual;
            if (atual == pLista1->primeiro) {
                // Inclusão antes do primeiro elemento
                pLista1->primeiro = pLista2->primeiro;
            }
        }
    } else {
        // O nome especificado não foi encontrado na lista, então apenas anexa a lista2 ao final da lista1
        TLista_append(pLista1, pLista2);
    }

    // Limpar a lista2 após a operação
    TLista_Inicia(pLista2);
}
