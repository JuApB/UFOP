#include <stdio.h>
#include <stdlib.h>
#include "busca.h"

int main() {

    // criar variaveis
    int X; // número a ser buscado
    int n; // quantidade de números no vetor
    scanf("%d %d", &X, &n);
    
    // aloca vetor
    int* v = aloca(n);

    le(v, n);

    // busca sequencial
    int retornoSeq = buscaSequencial(v, n, X);

    // ordena vetor
    quickSort(v, 0, n - 1);

    // busca binaria
    int retornoBin = buscaBinaria(v, n - 1, X);
    
    printf("%d %d\n", retornoSeq, retornoBin);

    return 0;
}
