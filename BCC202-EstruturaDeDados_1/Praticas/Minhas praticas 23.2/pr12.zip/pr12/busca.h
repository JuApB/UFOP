#ifndef BUSCA_H
#define BUSCA_H
#include <stddef.h>

int* aloca(int n);
void desaloca(int** vetor);
void le(int* vetor, int n);
int buscaSequencial(int* vetor, int n, int elemento);
void quickSort(int v[], int esq, int dir); 
int buscaBinaria(int* vetor, int n, int elemento);

#endif
