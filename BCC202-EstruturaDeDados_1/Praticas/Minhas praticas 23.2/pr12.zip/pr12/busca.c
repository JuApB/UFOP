#include "busca.h" 

#include <stdio.h>
#include <stdlib.h>

// Crie as funcoes que julgar necessario
int* aloca(int n) {
    int*v = (int*)malloc(n * sizeof(int));
    return v;
}

void desaloca(int** vetor) {
    free(*vetor);
    *vetor = NULL;
}

void le(int* vetor, int n) {
    for (int i = 0; i < n; i++) {
        scanf("%d", &vetor[i]);
    }
}

int buscaSequencial(int* vetor, int n, int elemento) {
    for (int i = 0; i < n; i++) {
        if (vetor[i] == elemento) {
            return i; // Elemento encontrado, retornar o índice
        }
    }

    return -1; // Elemento não encontrado, retornar -1
}

// Função de ordenação Quick Sort
void quickSort(int v[], int esq, int dir) {
    if (esq >= dir) {
        return;
    }

    int pivo = v[dir];
    int i = esq - 1;

    for (int j = esq; j < dir; j++) {
        if (v[j] <= pivo) {
            i++;
            int temp = v[i];
            v[i] = v[j];
            v[j] = temp;
        }
    }

    int temp = v[i + 1];
    v[i + 1] = v[dir];
    v[dir] = temp;

    int indiceDeParticao = i + 1;

    quickSort(v, esq, indiceDeParticao - 1);
    quickSort(v, indiceDeParticao + 1, dir);
}


int buscaBinaria(int* vetor, int n, int elemento) {
    int esq = 0, dir = n-1;
    while(esq <= dir){
        int meio = (esq + dir) / 2;

        if(vetor[meio] > elemento){
            dir = meio - 1; // Procurar na metade esquerda do vetor
        } else if(vetor[meio] < elemento){
            esq = meio + 1; // Procurar na metade direita do vetor
        } else{
            return meio; // Elemento encontrado, retornar o índice
        }
    }

    return -1; // Elemento não encontrado, retornar -1
}