Arquivo zip gerado em: 15/02/2023 14:40:21 
Este arquivo contém todos os casos de teste cadastrados até o momento, disponível apenas para professores/monitores. 
Para alterar um caso de teste acesse o sistema. 
Exercício: Prática 7