#include "ordenacao.h"
#include <stdio.h>
#include <stdlib.h>

// Manter como especificado
int* alocaVetor(int n){
    return (int *)malloc(n * sizeof(int));
}

// Manter como especificado
int* desalocaVetor(int* v){
    free(v);
    return NULL;
}

// Função auxiliar para trocar dois elementos em um vetor
void troca(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Manter como especificado
void ordenacao(int* v, int n, int* movimentos){
    *movimentos = 0;

    for(int i = 0; i < n; i++){
        for(int j = 1; j < n-i; j++){
            if(v[j] < v[j-1]){
                troca(&v[j], &v[j-1]);
                (*movimentos)++;
            }
        }
    }
}
