#include "sort.h"
#include <stdlib.h>

// Cabecalho das funcoes
void InsertionSort(int* v, int n, int* count);
void MergeSort(int* v, int esq, int dir, int* count);
void merge(int* v, int esq, int meio, int dir);

// Manter como especificado
int sort(int* v, int n) {
    int chamadas = 0;

    MergeSort(v, 0, n-1, &chamadas);

    return chamadas;
}

void InsertionSort(int* v, int n, int* count) {
    int j, chave;

    for (int i = 1; i < n; i++) {
        chave = v[i];
        j = i - 1;

        while (j >= 0 && v[j] > chave) {
            v[j + 1] = v[j];
            j--;
        }

        v[j + 1] = chave;
    }

    (*count)++;
}

void MergeSort(int* v, int esq, int dir, int* count) {
    if(esq < dir){
        if(dir - esq + 1 <= 10){
            InsertionSort(v + esq, dir - esq + 1, count);
        } else{
            int m = esq + (dir - esq) / 2;

            MergeSort(v, esq, m, count);
            MergeSort(v, m+1, dir, count);
            merge(v, esq, m, dir);
        }
    }
}

void merge(int* v, int esq, int meio, int dir) {
    int i, j, k;
    int tamEsq = meio - esq + 1, tamDir = dir - meio;
    int auxEsq[tamEsq], auxDir[tamDir];

    for (i = 0; i < tamEsq; i++)
        auxEsq[i] = v[esq + i];
    for (j = 0; j < tamDir; j++)
        auxDir[j] = v[meio + 1 + j];

    i=0, j=0, k=esq;

    while(i < tamEsq && j < tamDir){
        if (auxEsq[i] <= auxDir[j]) {
            v[k] = auxEsq[i];
            i++;
        } else {
            v[k] = auxDir[j];
            j++;
        }
        k++;
    }

    while(i < tamEsq){
        v[k] = auxEsq[i];
        i++;
        k++;
    }

    while (j < tamDir) {
        v[k] = auxDir[j];
        j++;
        k++;
    }
}
