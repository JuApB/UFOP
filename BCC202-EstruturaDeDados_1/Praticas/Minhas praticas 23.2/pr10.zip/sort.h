#ifndef SORT_H
#define SORT_H

// Manter como especificado
int sort(int*, int);

#endif // SORT_H