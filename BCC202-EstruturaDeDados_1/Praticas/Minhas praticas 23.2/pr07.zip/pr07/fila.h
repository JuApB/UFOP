#ifndef FILA_H
#define FILA_H

#include <stdbool.h>
#include "item.h"

// Manter como especificado
typedef struct fila {
    Item itens[MAX_TAM];
    int ini;
    int fim;
} Fila;

// Manter como especificado
Fila* FilaCria();
// Manter como especificado
Fila* FilaDestroi(Fila*);
// Manter como especificado
bool FilaEhVazia(Fila*);
// Manter como especificado
bool FilaEnfileira(Fila*, Item);
// Manter como especificado
bool FilaDesenfileira(Fila*, Item*);
// Manter como especificado
int FilaTamanho(Fila*);
// Manter como especificado
void FilaImprime(Fila*);

#endif // FILA_H