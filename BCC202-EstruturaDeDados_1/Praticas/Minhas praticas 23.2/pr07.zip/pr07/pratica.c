#include <stdio.h>

#include "pilhadupla.h"
#include "fila.h"

int main() {
    Item item;
    Fila* fila = FilaCria();
    PilhaDupla* pilhas = PilhaDuplaCria();

    int id = 0;  // Inicia com a pilha 0

    while (scanf("%d", &item.chave) && item.chave != 0) {
        // Inserir item lido na respectiva pilha
        // Valores pares na pilha 0 e ímpares na pilha 1
        int pilhaId = (item.chave % 2 == 0) ? 0 : 1;
        PilhaPush(pilhas, pilhaId, item);
    }

    while (!PilhaEhVazia(pilhas, 0) || !PilhaEhVazia(pilhas, 1)) {
        // Enquanto houver itens nas pilhas, remover alternadamente
        // Se o item for positivo, enfileirar na fila, se for negativo, desenfileirar

        int pilhaId = id % 2;  // Alterna entre as pilhas 0 e 1
        
        if (!PilhaEhVazia(pilhas, pilhaId)) {
            PilhaPop(pilhas, pilhaId, &item);
            if (item.chave > 0) {
                FilaEnfileira(fila, item);
            } else {
                Item removido;
                FilaDesenfileira(fila, &removido);
            }
        }

        id++;  // Avança para a próxima pilha na próxima iteração
    }

    // Imprimir fila
    FilaImprime(fila);

    // Destruir a fila e a pilha dupla
    fila = FilaDestroi(fila);
    pilhas = PilhaDuplaDestroi(pilhas);

    return 0;
}