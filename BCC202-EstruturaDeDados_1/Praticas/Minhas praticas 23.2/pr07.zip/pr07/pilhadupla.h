#ifndef PILHA_DUPLA_H
#define PILHA_DUPLA_H

#include <stdbool.h>
#include "item.h"

// Manter como especificado
typedef struct {
    // Usar um unico vetor para manter as duas pilhas
    Item itens[MAX_TAM];
    int tamP1;
    int tamP2;
} PilhaDupla;

// Manter como especificado
PilhaDupla* PilhaDuplaCria();
// Manter como especificado
PilhaDupla* PilhaDuplaDestroi(PilhaDupla*);
// Manter como especificado
bool PilhaEhVazia(PilhaDupla*, int);
// Manter como especificado
bool PilhaEhCheia(PilhaDupla*, int);
// Manter como especificado
bool PilhaPush(PilhaDupla*, int, Item);
// Manter como especificado
bool PilhaPop(PilhaDupla*, int, Item*);
// Manter como especificado
int PilhaTamanho(PilhaDupla*, int);
// Manter como especificado
void PilhaImprime(PilhaDupla*, int);

#endif // !PILHA_DUPLA_H