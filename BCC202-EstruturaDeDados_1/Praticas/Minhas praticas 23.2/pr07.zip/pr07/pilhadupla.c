#include "pilhadupla.h"

#include <stdio.h>
#include <stdlib.h>

// Manter como especificado
PilhaDupla* PilhaDuplaCria() {
    PilhaDupla* pilha = (PilhaDupla*)malloc(sizeof(PilhaDupla));
    pilha->tamP1 = 0;
    pilha->tamP2 = 0;
    return pilha;
}

// Manter como especificado
PilhaDupla* PilhaDuplaDestroi(PilhaDupla* pPilhas) {
    free(pPilhas);
    return NULL;
}

// Manter como especificado
bool PilhaEhVazia(PilhaDupla* pPilhas, int id) {
    return (id == 0 && pPilhas->tamP1 == 0) || (id == 1 && pPilhas->tamP2 == 0);
}

// Manter como especificado
bool PilhaEhCheia(PilhaDupla* pPilhas, int id) {
    return (id == 0 && pPilhas->tamP1 == MAX_TAM / 2) || (id == 1 && pPilhas->tamP2 == MAX_TAM / 2);
}

// Manter como especificado
bool PilhaPush(PilhaDupla* pPilhas, int id, Item item) {
    if (PilhaEhCheia(pPilhas, id)) {
        return false;  // Pilha cheia
    }

    if (id == 0) {
        pPilhas->itens[pPilhas->tamP1] = item;
        pPilhas->tamP1++;
    } else {
        pPilhas->itens[MAX_TAM / 2 + pPilhas->tamP2] = item;
        pPilhas->tamP2++;
    }

    return true;
}

// Manter como especificado
bool PilhaPop(PilhaDupla* pPilhas, int id, Item* pItem) {
    if (PilhaEhVazia(pPilhas, id)) {
        return false;  // Pilha vazia
    }

    if (id == 0) {
        pPilhas->tamP1--;
        *pItem = pPilhas->itens[pPilhas->tamP1];
    } else {
        pPilhas->tamP2--;
        *pItem = pPilhas->itens[MAX_TAM / 2 + pPilhas->tamP2];
    }

    return true;
}

// Manter como especificado
int PilhaTamanho(PilhaDupla* pPilhas, int id) {
    return (id == 0) ? pPilhas->tamP1 : pPilhas->tamP2;
}

// Manter como especificado
void PilhaImprime(PilhaDupla* pPilhas, int id) {
    printf("Pilha %d: [", id);
    for (int i = 0; i < PilhaTamanho(pPilhas, id); i++) {
        if (id == 0)
            printf("(%d) ", pPilhas->itens[i].chave);
        else
            printf("(%d) ", pPilhas->itens[MAX_TAM / 2 + i].chave);
    }
    printf("]\n");
}
