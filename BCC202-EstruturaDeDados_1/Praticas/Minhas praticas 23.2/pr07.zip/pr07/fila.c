#include "fila.h"

#include <stdlib.h>
#include <stdio.h>

// Manter como especificado
Fila* FilaCria() {
    Fila* fila = (Fila*)malloc(sizeof(Fila));
    fila->ini = 0;
    fila->fim = 0;
    return fila;
}

// Manter como especificado
Fila* FilaDestroi(Fila* pFila) {
    free(pFila);
    return NULL;
}

// Manter como especificado
bool FilaEhVazia(Fila* pFila) {
    return pFila->ini == pFila->fim;
}

// Manter como especificado
bool FilaEhCheia(Fila* pFila) {
    return (pFila->fim + 1) % MAX_TAM == pFila->ini;
}

// Manter como especificado
bool FilaEnfileira(Fila* pFila, Item item) {
    if (FilaEhCheia(pFila)) {
        return false;  // Fila cheia
    }

    pFila->itens[pFila->fim] = item;
    pFila->fim = (pFila->fim + 1) % MAX_TAM;

    return true;
}

// Manter como especificado
bool FilaDesenfileira(Fila* pFila, Item* pItem) {
    if (FilaEhVazia(pFila)) {
        return false;  // Fila vazia
    }

    *pItem = pFila->itens[pFila->ini];
    pFila->ini = (pFila->ini + 1) % MAX_TAM;

    return true;
}

// Manter como especificado
int FilaTamanho(Fila* pFila) {
    return (pFila->fim - pFila->ini + MAX_TAM) % MAX_TAM;
}

// Manter como especificado
void FilaImprime(Fila* pFila) {
    printf("Fila: [");
        for (int i=0;i<FilaTamanho(pFila);i++)
            printf("(%d) ", pFila->itens[(pFila->ini + i) % MAX_TAM].chave);
    printf("]\n");
}