#ifndef ITEM_H
#define ITEM_H

#define MAX_TAM 1000

typedef struct {
    int chave;
} Item;

#endif // !ITEM_H