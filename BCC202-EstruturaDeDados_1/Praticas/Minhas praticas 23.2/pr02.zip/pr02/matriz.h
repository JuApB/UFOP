#ifndef MATRIZ
#define MATRIZ

// Usar passagem por referencia
void lerOrdem(int*);

// Usar passagem por referencia
void lerOperacao(char*);

// Manter como especificado
double** alocaMatriz(int);

// Manter como especificado
double** desalocaMatriz(double**, int);

// Manter como especificado
void lerMatriz(double**, int);

// Manter como especificado
double somaMatriz(double**, int);

// Manter como especificado
double media(double, int);

// Manter como especificado
void printResultado(double);

#endif