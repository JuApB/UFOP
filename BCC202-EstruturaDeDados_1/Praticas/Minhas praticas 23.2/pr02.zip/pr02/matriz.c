#include "matriz.h"
#include <stdio.h>
#include <stdlib.h>

// Manter como especificado
void lerOrdem(int* ordem) {
    // PREENCHER AQUI
    scanf("%d", ordem);
}

// Manter como especificado
double** alocaMatriz(int ordem) {
    // PREENCHER AQUI
    double** matriz = (double**)malloc(ordem * sizeof(double*));
    for (int i = 0; i < ordem; i++) {
        matriz[i] = (double*)malloc(ordem * sizeof(double));
    }
    return matriz;
}

// Manter como especificado
double **desalocaMatriz(double** matriz, int ordem) {
    // PREENCHER AQUI
    for (int i = 0; i < ordem; i++) {
        free(matriz[i]);
    }
    free(matriz);
    matriz = NULL;
    return matriz;
}

// Manter como especificado
void lerOperacao(char* operacao) {
    // PREENCHER AQUI
    scanf(" %c", operacao); // Note o espaço antes do %c para consumir espaços em branco
}

// Manter como especificado
void lerMatriz(double** matriz, int ordem) {
    // PREENCHER AQUI
    for (int i = 0; i < ordem; i++) {
        for (int j = 0; j < ordem; j++) {
            scanf("%lf", &matriz[i][j]);
        }
    }
}

// Manter como especificado
double somaMatriz(double** matriz, int ordem) {
    // PREENCHER AQUI
    double soma = 0.0;
    for (int i = 0; i < ordem; i++) {
        for (int j = 0; j < ordem; j++) {
            if (i < j && i + j < (ordem-1)) { // Verifique se estamos na área superior
                soma += matriz[i][j];
            }
        }
    }
    return soma;
}

// Manter como especificado
double media(double resultado, int ordem) {
    // PREENCHER AQUI
    int total = 0, n;
    for (int i = 0; i < ordem; i++) {
        for (int j = 0; j < ordem; j++) {
            if (i < j && i + j < (ordem-1)) { // Fazendo a contagem dos elementos
                total++;
            }
        }
    }
    n = resultado / total;
    return n;
}

// Manter como especificado
void printResultado(double resultado) {
    // PREENCHER AQUI
    printf("%.1lf\n", resultado);
}
